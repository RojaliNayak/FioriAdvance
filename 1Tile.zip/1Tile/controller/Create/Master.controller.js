/*global history */
jQuery.sap.require("sap.m.MessageBox");
sap.ui.define([
	"YRTV_ONE_TILE/YRTV_ONE_TILE/controller/CreateVerify/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/GroupHeaderListItem",
	"sap/ui/Device",
	"YRTV_ONE_TILE/YRTV_ONE_TILE/model/CreateVerify/formatter",
	"sap/m/MessageToast",
	"sap/ui/core/ValueState",
	"sap/ui/core/format/DateFormat",
	"sap/ui/ux3/OverlayContainer",
	"sap/m/Dialog",
	"sap/m/Button",
	"sap/m/Text",
	"sap/ui/core/routing/History"
], function (BaseController, JSONModel, Filter, FilterOperator, GroupHeaderListItem, Device, formatter, MessageToast, ValueState,
	DateFormat, OverlayContainer, Dialog, Button, Text, History) {
	"use strict";
	var __controller__;
	var walkThroughUI = function (root, fnCallback) {
		if (!root)
			return;
		fnCallback(root);
		$.each(root.findAggregatedObjects(true), function (i, control) {
			fnCallback(control);
		});
	};
	var includeByClass = function (__class, fn) {
		return function (element) {
			if (element instanceof __class) {
				fn(element);
			}
		};
	};
	var includeByData = function (key, value, fn) {
		return function (element) {
			if (value === element.data(key)) {
				fn(element);
			}
		};
	};
	var labelStyleClass = function (labelNum) {
		var labelColor = labelNum.substring(4, 5);
		return COLOR_MAPPING[labelColor] ? COLOR_MAPPING[labelColor].styleClass : "";
	};
	var COLOR_MAPPING = {
		"1": {
			styleClass: "redLabelListItem",
			placeholder: "Red"
		},
		"2": {
			styleClass: "yellowLabelListItem",
			placeholder: "Yellow"
		},
		"3": {
			styleClass: "greenLabelListItem",
			placeholder: "Green"
		},
		"4": {
			styleClass: "whiteLabelListItem",
			placeholder: "White"
		}
	};
	return BaseController.extend("YRTV_ONE_TILE.YRTV_ONE_TILE.controller.CreateVerify.Master", {
		formatter: formatter,
		onInit: function () {
			this.getOwnerComponent().createVerifyComp();

			// var oListSelector = this.getOwnerComponent().oListSelector;

			// oListSelector.attachListSelectionChange(function () {
			// 	this.byId("idAppControl").hideMaster();
			// }, this);
			this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());
			//https://help.sap.com/saphelp_gateway20sp08/helpdata/en/71/d07b52a3566f54e10000000a44176d/content.htm
			__controller__ = this;
			this.siteId = "";
			var oList = this.byId("list"),
				oViewModel = this._createViewModel(),
				iOriginalBusyDelay = oList.getBusyIndicatorDelay();
			var oDataModel = this.getGlobalModel();
			this.setModel(oDataModel, "oDataModel");
			var oBinding = oList.getBinding("items");
			this._AuthorizationAccess();
			this._oList = oList;
			this._oListFilterState = {
				aFilter: [],
				aSearch: []
			};
			this.setModel(oViewModel, "masterView");
			this.getView().addEventDelegate({
				onBeforeFirstShow: function () {
					this.getOwnerComponent().oListSelector.setBoundMasterList(oList);
					this.byId("searchField").focus();
					__controller__.onVKeypadHide();
				}.bind(this),
				onAfterShow: function () {
					this.byId("searchField").focus();
					__controller__.onVKeypadHide();
				}.bind(this)
			});
			oList.attachEventOnce("updateFinished", function () {
				this.byId("searchField").focus();
				__controller__.onVKeypadHide();
			}.bind(this));
			this.getRouter().attachRouteMatched(this._onMasterMatched, this);
			this.getRouter().attachBypassed(this.onBypassed, this);
			var controller = this;
			var VerifyObjectListItem = this.byId("VerifyObjectListItem");
			VerifyObjectListItem.addDelegate({
				onBeforeRendering: function () {
					if (!this.data("iconPressReloaded")) {
						if (this.getBindingContext("oDataModel")) {
							var __object__ = this.getBindingContext("oDataModel").getObject();
							if (__object__) {
								if (__object__.ThumnailImage) {
									this._getImageControl().attachPress(this.getBindingContext("oDataModel").getObject(), controller.onPressIcon, controller);
									this.data("iconPressReloaded", "X");
								}
							}
						}
					}
				},
				onAfterRendering: function () {
					if (this.data("search") === "X") {
						this.addStyleClass("searchResult");
					} else {
						this.removeStyleClass("searchResult");
					}
				}
			}, false, VerifyObjectListItem, true);
			var LabelItemList = this.byId("LabelItemList");
			LabelItemList.addDelegate({
				onAfterRendering: function () {
					this.removeStyleClass("yellowLabelListItem").removeStyleClass("redLabelListItem").removeStyleClass("greenLabelListItem").removeStyleClass(
						"whiteLabelListItem");
					if (this.getBindingContext("oDataModel")) {
						var __object__ = this.getBindingContext("oDataModel").getObject();
						controller.getModel("masterView").setProperty("/siteId", __object__.Werks);
						//For GA
						if (__object__.LabelColor) {
							this.addStyleClass(labelStyleClass(__object__.LabelNum));
						}
					}
					if (this.data("search") === "X") {
						this.addStyleClass("searchResult");
					} else {
						this.removeStyleClass("searchResult");
					}
				}
			}, false, LabelItemList, true);
			sap.ui.getCore().getEventBus().subscribe("rtv.verify", "RefreshMasterList", function () {
				controller.onRefresh();
			}, this);
			sap.ui.getCore().getEventBus().subscribe("rtv.verify", "ClearMasterLisSelection", function () {
				this.byId("list").removeSelections(true);
				this.byId("searchField").setValue("");
			}, this);
		},
		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */
		/**
		 * After list data is available, this handler method updates the
		 * master list counter and hides the pull to refresh control, if
		 * necessary.
		 * @param {sap.ui.base.Event} oEvent the update finished event
		 * @public
		 */
		onUpdateFinished: function (oEvent) {
			sap.ui.core.BusyIndicator.show();
			this._updateListItemCount(oEvent.getParameter("total"));
			this.byId("pullToRefresh").hide();
			this.siteId = this.getModel("masterView").getData().siteId;
			this.getOwnerComponent().googleAnalyticUpdate({
				page: "Verify",
				site: this.siteId
			}); //Google Analytics
			sap.ui.core.BusyIndicator.hide();
			// var oVendorNameModel = this.getModel("oVendorNameModel");
		},
		/**
		 * Event handler for refresh event. Keeps filter, sort
		 * and group settings and refreshes the list binding.
		 * @public
		 */
		onRefresh: function () {
			this.byId("list").getBinding("items").refresh();
		},
		onSelectionChange: function (oEvent) {
			var item = oEvent.getParameter("listItem") || oEvent.getSource();
			var messageText = "FromVerifyToVerify";
			var controller = this;
			if (this.getView().getParent().getParent().getCurrentDetailPage().getId().indexOf("createDetail") !== -1) {
				messageText = "FromCreateToVerify";
			} else {
				controller.byId("searchField").setValue("");
				controller.byId("idCreateRTVBtn").setEnabled(true);
				controller._AuthorizationAccess(item);
				// controller._showDetail(item);
				return;
			}
			var dialog = new Dialog({
				title: this.getResourceBundle().getText("Warning"),
				type: "Message",
				state: "Warning",
				content: new Text({
					text: this.getResourceBundle().getText(messageText)
				}),
				beginButton: new Button({
					text: this.getResourceBundle().getText("Yes"),
					press: function () {
						dialog.close();
						controller.byId("searchField").setValue("");
						controller.byId("idCreateRTVBtn").setEnabled(true);
						controller._AuthorizationAccess(item); // controller._showDetail(item);
					}
				}),
				endButton: new Button({
					text: this.getResourceBundle().getText("Cancel"),
					press: function () {
						dialog.close();
						item.setSelected(false);
						controller.labelNum = "";
						controller.syncSelection();
						controller.byId("searchField").focus();
						__controller__.onVKeypadHide();
					}
				}),
				afterClose: function () {
					dialog.destroy();
				}
			});
			dialog.open();
		},
		/**
		 * Event handler for the bypassed event, which is fired when no routing pattern matched.
		 * If there was an object selected in the master list, that selection is removed.
		 * @public
		 */
		onBypassed: function () {
			this._oList.removeSelections(true);
		},
		/**
		 * Used to create GroupHeaders with non-capitalized caption.
		 * These headers are inserted into the master list to
		 * group the master list's items.
		 * @param {Object} oGroup group whose text is to be displayed
		 * @public
		 * @returns {sap.m.GroupHeaderListItem} group header with non-capitalized caption.
		 */
		createGroupHeader: function (oGroup) {
			return new GroupHeaderListItem({
				title: oGroup.text,
				upperCase: false
			});
		},
		/**
		 * Event handler for navigating back.
		 * It there is a history entry or an previous app-to-app navigation we go one step back in the browser history
		 * If not, it will navigate to the shell home
		 * @public
		 */
		onNavHome: function () {
				this.getOwnerComponent().getRouter().navTo("home", true);
		},
		
		onMenuButtonPress: function () {
			var oRouter = this.getOwnerComponent().getRouter();
			oRouter.navTo("Menu", {});
		},
		/* =========================================================== */
		/* begin: internal methods                                     */
		/* =========================================================== */
		_createViewModel: function () {
			return new JSONModel({
				isFilterBarVisible: false,
				filterBarLabel: "",
				delay: 0,
				title: this.getResourceBundle().getText("masterTitleCount", [0]),
				noDataText: this.getResourceBundle().getText("masterListNoDataText"),
				sortBy: "Description",
				groupBy: "None"
			});
		},
		/**
		 * If the master route was hit (empty hash) we have to set
		 * the hash to to the first item in the list as soon as the
		 * listLoading is done and the first item in the list is known
		 * @private
		 */
		_onMasterMatched: function (oEvent) {

			var oParameters = oEvent.getParameters();
			if (oParameters.name === "master") {
				this.getView().byId("idCreateRTVBtn").setEnabled(true);
			} else if (oParameters.name === "verify") {
				this.labelNum = oParameters.arguments.LabelNum;
				if (this.labelNum) {
					var oList = this.byId("list"),
						items = oList.getItems();
					if (!$.isArray(items) || items.length == 0) {
						oList.attachEventOnce("updateFinished", this.syncSelection.bind(this));
					} else {
						this.syncSelection();
					}
				}
			}
		},
		syncSelection: function () {
			var oList = this.byId("list"),
				items = oList.getItems(),
				labelNum = this.labelNum;
			if (items) {
				var __item__;
				items.forEach(function (item) {
					if (item) {
						var __object__ = item.getBindingContext("oDataModel").getObject();
						if (__object__.LabelNum) {
							if (labelNum === __object__.LabelNum) {
								if (!__item__) {
									__item__ = item;
								}
							}
						}
					}
				});
				if (__item__) {
					if (__item__ !== oList.getSelectedItem()) {
						oList.setSelectedItem(__item__, true);
						this.byId("MasterPage").scrollToElement(__item__, 500);
					}
				} else {
					oList.removeSelections();
				}
			}
		},
		/**
		 * Sets the item count on the master list header
		 * @param {integer} iTotalItems the total number of items in the list
		 * @private
		 */
		_updateListItemCount: function (iTotalItems) {
			var sTitle;
			// only update the counter if the length is final
			if (this._oList.getBinding("items").isLengthFinal()) {
				sTitle = this.getResourceBundle().getText("masterTitleCount", [iTotalItems]);
				this.getModel("masterView").setProperty("/title", sTitle);
			}
			if (iTotalItems === 0) {
				var oMessage = this.getResourceBundle().getText("NoLabelsFound");
				MessageToast.show(oMessage);
			}
		},
		/**
		 * Internal helper method to apply both filter and search state together on the list binding
		 * @private
		 */
		_applyFilterSearch: function () {
			var aFilters = this._oListFilterState.aSearch.concat(this._oListFilterState.aFilter),
				oViewModel = this.getModel("masterView");
			this._oList.getBinding("items").filter(aFilters, "Application");
			// changes the noDataText of the list in case there are no filter results
			if (aFilters.length !== 0) {
				oViewModel.setProperty("/noDataText", this.getResourceBundle().getText("masterListNoDataWithFilterOrSearchText"));
			} else if (this._oListFilterState.aSearch.length > 0) {
				// only reset the no data text to default when no new search was triggered
				oViewModel.setProperty("/noDataText", this.getResourceBundle().getText("masterListNoDataText"));
			}
		},
		/**
		 * Internal helper method to apply both group and sort state together on the list binding
		 * @param {sap.ui.model.Sorter[]} aSorters an array of sorters
		 * @private
		 */
		_applyGroupSort: function (aSorters) {
			this._oList.getBinding("items").sort(aSorters);
		},
		/**
		 * Internal helper method that sets the filter bar visibility property and the label's caption to be shown
		 * @param {string} sFilterBarText the selected filter value
		 * @private
		 */
		_updateFilterBar: function (sFilterBarText) {
			var oViewModel = this.getModel("masterView");
			oViewModel.setProperty("/isFilterBarVisible", this._oListFilterState.aFilter.length > 0);
			oViewModel.setProperty("/filterBarLabel", this.getResourceBundle().getText("masterFilterBarText", [sFilterBarText]));
		},
		createArticleModel: function (data) {
			if (data) {
				this.getModel("articleModel").setData(data, true);
			} else {
				this.getModel("articleModel").setData({
					ReasonCode: "",
					Article: "",
					OrderNumber: ""
				});
			}
		},
		beforeOpenDialog: function () {
			this.createArticleModel();
			sap.ui.getCore().byId("idDReasonCode").destroyItems().clearSelection();
			sap.ui.getCore().byId("idDArticle").setValueState(sap.ui.core.ValueState.None).setValueStateText("").setValue("");
		},
		getCreateDialog: function () {
			// create dialog lazily
			if (!this._oDialog) {
				// create dialog via fragment factory
				this._oDialog = sap.ui.xmlfragment("YRTV_ONE_TILE.YRTV_ONE_TILE.view.CreateVerify.CreateLabel", this);
				// connect dialog to view (models, lifecycle)
				this.getView().addDependent(this._oDialog);
				this._oDialog.attachAfterClose(function () {
					this.byId("searchField").focus();
					__controller__.onVKeypadHide();
				}.bind(this));
				var articleFld = sap.ui.getCore().byId("idDArticle");
				if (articleFld) {
					if (articleFld.refreshDataState) {
						articleFld.refreshDataState = $.noop;
					}
					this._oDialog.attachAfterOpen(function () {
						articleFld.focus();
					});
				}
			}
			sap.ui.getCore().byId("idDReasonCode").setEnabled(false);
			return this._oDialog;
		},
		//Build PSC Search pop-up
		onFilterSearch: function () {
			if (!this._ofDialog) {
				this._ofDialog = sap.ui.xmlfragment("YRTV_ONE_TILE.YRTV_ONE_TILE.view.CreateVerify.AdvancedSearch", this);
				this.getView().addDependent(this._ofDialog);
			}
			this._ofDialog.open();
		},
		//Open PSC Seacrh Pop-up
		onDialogRTVSearchPress: function () {

			this.oPSCsearch();
		},
		//Function to filter labels based on PSC selection
		oPSCsearch: function () {

			//Reste Detail Page once Filter is set
			this.getRouter().navTo("master", {}, true);
			var aFilters = [],
				oSelVal,
				//Region Dropdown
				oRegionVal = sap.ui.getCore().byId("idRegion"),
				//District Dropdown
				oDistrictVal = sap.ui.getCore().byId("idDistrict"),
				//Store Value
				oStoreVal = sap.ui.getCore().byId("idStore"),
				// oStoreDrop = sap.ui.getCore().byId("idStoreSel"),
				//Vendor
				oLifnr = sap.ui.getCore().byId("idVendor").getValue(),
				//Order
				oOrderNumber = sap.ui.getCore().byId("idOrder").getValue(),
				//Selection
				oKeySelection = sap.ui.getCore().byId("idSelection"),
				oSelKey = oKeySelection.getSelectedKey(),
				//filter label text
				oFilterLabel = this.getView().byId("filterBar");
			//Get all stores
			if (oSelKey === "1") {
				oSelVal = oRegionVal.getSelectedItem().getKey();
				if (oSelVal !== "") {
					aFilters.push(new Filter("SELKEY", sap.ui.model.FilterOperator.EQ, oSelKey));
					aFilters.push(new Filter("SELVAL", sap.ui.model.FilterOperator.EQ, oSelVal));
				}

			} else if (oSelKey === "2") {
				oSelVal = oDistrictVal.getSelectedItem().getKey();
				if (oSelVal !== "") {
					aFilters.push(new Filter("SELKEY", sap.ui.model.FilterOperator.EQ, oSelKey));
					aFilters.push(new Filter("SELVAL", sap.ui.model.FilterOperator.EQ, oSelVal));
				}
				//If store is selected just pass all the stores
			} else if (oSelKey === "3") {
				oSelVal = oStoreVal.getValue().slice(0, 4);
				if (oSelVal !== "") {
					aFilters.push(new Filter("SELKEY", sap.ui.model.FilterOperator.EQ, oSelKey));
					aFilters.push(new Filter("SELVAL", sap.ui.model.FilterOperator.EQ, oSelVal));
				}

			} else {
				//if nothing selected keep the variable null	
				oSelVal = "";
			}
			//Get Vendor
			if (oLifnr !== "") {
				aFilters.push(new Filter("Lifnr", sap.ui.model.FilterOperator.EQ, oLifnr));
			}
			//Get order number and pass in both normal Order and refrence order
			if (oOrderNumber !== "") {
				aFilters.push(new Filter("OrderNumber", sap.ui.model.FilterOperator.EQ, oOrderNumber));
				aFilters.push(new Filter("ReferenceOrder", sap.ui.model.FilterOperator.EQ, oOrderNumber));
			}
			//Show the Label
			oFilterLabel.setVisible(true);
			//FIlter the list based on above seection
			var oList = this.byId("list");
			var oBinding = oList.getBinding("items");
			oBinding.filter(aFilters, "Application");
			//CLose the popup
			this.onDialogRTVClose();
			// this._ofDialog.close();

		},
		onClearFilter: function () {
			this.getRouter().navTo("master", {}, true);
			var oList = this.byId("list"),
				aFilters = [];
			var oBinding = oList.getBinding("items");
			oBinding.filter(aFilters, "Application");
			this.onDialogRTVResetPress();
			//filter label text
			var oFilterLabel = this.getView().byId("filterBar");
			//Show the Label
			oFilterLabel.setVisible(false);
		},
		onDialogRTVClosePress: function () {
			this.onDialogRTVResetPress();
			this.onDialogRTVClose();

		},
		onDialogRTVClose: function () {

			var oSelection = sap.ui.getCore().byId("idSelection"),
				oSelKey = oSelection.getSelectedKey(),
				oSelVal,
				//Region Dropdown
				oRegionVal = sap.ui.getCore().byId("idRegion"),
				//District Dropdown
				oDistrictVal = sap.ui.getCore().byId("idDistrict"),
				//Store Value
				oStoreVal = sap.ui.getCore().byId("idStore");

			if (oSelKey === "1") {
				oSelVal = oRegionVal.getSelectedItem().getKey();
				if (oSelVal === "") {
					oRegionVal.setVisible(false);
				}
			} else if (oSelKey === "2") {
				oSelVal = oDistrictVal.getSelectedItem().getKey();
				if (oSelVal === "") {
					oDistrictVal.setVisible(false);
				}

			} else if (oSelKey === "3") {
				oSelVal = oStoreVal.getValue().slice(0, 4);
				if (oSelVal === "") {
					oStoreVal.setVisible(false);
				}
			}
			//Put back the selection
			oSelection.setSelectedKey("0");
			this._ofDialog.close();

		},

		//Close Button PSC Search pop-up
		onDialogRTVResetPress: function () {
			//Re Runn the filter with no values
			this.getRouter().navTo("master", {}, true);
			//Get all elements from pop-up
			var oRegionVal = sap.ui.getCore().byId("idRegion");
			var oDistrictVal = sap.ui.getCore().byId("idDistrict");
			var oStoreVal = sap.ui.getCore().byId("idStore");
			var oSelection = sap.ui.getCore().byId("idSelection");
			var oLifnr = sap.ui.getCore().byId("idVendor");
			var oOrderNumber = sap.ui.getCore().byId("idOrder");
			var oSearchBtn = sap.ui.getCore().byId("searchButton");
			//Hide Region dropdown
			//Hide District dropdown
			//Hide Store input filed
			oRegionVal.setVisible(false);
			oDistrictVal.setVisible(false);
			oStoreVal.setVisible(false);
			//Pass null values to all fileds
			oSelection.setSelectedKey("0");
			oRegionVal.setSelectedKey("");
			oDistrictVal.setSelectedKey("");
			oLifnr.setValue("");
			oOrderNumber.setValue("");
			oStoreVal.setValue("");
			oSearchBtn.setEnabled(false);

		},
		//CHange of Selection
		onStoreSelectionChange: function (oEvent) {
			//Get all elements from the screen
			var oSelectedItem = oEvent.getParameters().selectedItem.getKey();
			var oRegionModel = this.getModel("oRegionModel");
			var oRegionVal = sap.ui.getCore().byId("idRegion");
			var oDistrictVal = sap.ui.getCore().byId("idDistrict");
			var oStoreVal = sap.ui.getCore().byId("idStore");
			var oSearchBtn = sap.ui.getCore().byId("searchButton");
			var oStoreInput = sap.ui.getCore().byId("idStore").getValue(),
				oVendorInput = sap.ui.getCore().byId("idVendor").getValue(),
				oOrderInput = sap.ui.getCore().byId("idOrder").getValue();
			//No Selection
			if (oSelectedItem === "0") {
				//Hide all drop down for Region/District and Store Input fields
				oRegionVal.setVisible(false);
				oDistrictVal.setVisible(false);
				oStoreVal.setVisible(false);
				//Clear Region/Distrct/Store Values
				oRegionVal.setSelectedKey("");
				oDistrictVal.setSelectedKey("");
				oStoreVal.setValue("");
				//IF Vendor or Order is also inital disable search button else enable it
				if ((oStoreInput === "") && (oVendorInput === "") && (oOrderInput === "")) {
					oSearchBtn.setEnabled(false);
				}
				//Region selection
			} else if (oSelectedItem === "1") {
				//Get keys of initial selection
				var aRtos = [];
				var oNewRto = {};
				oNewRto.key = "09";
				oNewRto.text = this.getResourceBundle().getText("East");
				aRtos.push(oNewRto);
				oNewRto = {};
				oNewRto.key = "32";
				oNewRto.text = this.getResourceBundle().getText("West");
				aRtos.push(oNewRto);
				oRegionModel.setProperty("/Region", aRtos);
				oRegionVal.setVisible(true);
				oDistrictVal.setVisible(false);
				oStoreVal.setVisible(false);
				if ((oVendorInput === "") && (oOrderInput === "")) {
					oSearchBtn.setEnabled(false);
				} else {
					oSearchBtn.setEnabled(true);
				}
				//District Selection
			} else if (oSelectedItem === "2") {

				oRegionVal.setVisible(false);
				oDistrictVal.setVisible(true);
				oStoreVal.setVisible(false);
				if ((oVendorInput === "") && (oOrderInput === "")) {
					oSearchBtn.setEnabled(false);
				} else {
					oSearchBtn.setEnabled(true);
				}
				//Store Selection
			} else if (oSelectedItem === "3") {

				oRegionVal.setVisible(false);
				oDistrictVal.setVisible(false);
				oStoreVal.setVisible(true);

			}

		},
		//On Region Dropdown change
		onRegionChange: function (oEvent) {
			var oRegionVal = sap.ui.getCore().byId("idRegion"),
				oSelectedText = oRegionVal.getSelectedItem().getText(),
				oSearchBtn = sap.ui.getCore().byId("searchButton"),
				oVendor = sap.ui.getCore().byId("idVendor").getValue(),
				oStoreVal = sap.ui.getCore().byId("idStore").getValue(),
				oOrder = sap.ui.getCore().byId("idOrder").getValue();
			if (oSelectedText.slice(0, 6) === "Select") {
				if ((oStoreVal === "") && (oVendor === "") && (oOrder === "")) {
					oSearchBtn.setEnabled(false);
				}

			} else {
				oSearchBtn.setEnabled(true);
			}

		},
		//on District Dropdown change
		onDistrictChange: function (oEvent) {
			var oDistrictVal = sap.ui.getCore().byId("idDistrict"),
				oSelectedText = oDistrictVal.getSelectedItem().getText(),
				oSearchBtn = sap.ui.getCore().byId("searchButton"),
				oVendor = sap.ui.getCore().byId("idVendor").getValue(),
				oStoreVal = sap.ui.getCore().byId("idStore").getValue(),
				oOrder = sap.ui.getCore().byId("idOrder").getValue();
			if (oSelectedText.slice(0, 6) === "Select") {
				if ((oStoreVal === "") && (oVendor === "") && (oOrder === "")) {
					oSearchBtn.setEnabled(false);
				}

			} else {
				oSearchBtn.setEnabled(true);
			}

		},
		//on Store Change
		onStoreChange: function (oEvent) {
			var oSearchBtn = sap.ui.getCore().byId("searchButton");
			oSearchBtn.setEnabled(true);
		},
		// Disable search button with clear input
		onStoreInp: function (oEvent) {

			var oSearchBtn = sap.ui.getCore().byId("searchButton");
			var oStoreVal = sap.ui.getCore().byId("idStore").getValue(),
				oVendor = sap.ui.getCore().byId("idVendor").getValue(),
				oOrder = sap.ui.getCore().byId("idOrder").getValue(),
				oDistrictVal = sap.ui.getCore().byId("idDistrict").getSelectedItem().getText(),
				oRegionVal = sap.ui.getCore().byId("idRegion").getSelectedItem().getText();
			if ((oStoreVal === "") && (oVendor === "") && (oOrder === "") && (oDistrictVal.slice(0, 6) === "Select") && (oRegionVal.slice(0, 6) ===
					"Select")) {
				oSearchBtn.setEnabled(false);
			}
		},
		// Disable search button with clear input
		onVendorInputClear: function (oEvent) {
			var oVendor = sap.ui.getCore().byId("idVendor").getValue();
			var oStoreVal = sap.ui.getCore().byId("idStore").getValue();
			var oOrder = sap.ui.getCore().byId("idOrder").getValue();
			var oSearchBtn = sap.ui.getCore().byId("searchButton"),
				oDistrictVal = sap.ui.getCore().byId("idDistrict").getSelectedItem().getText(),
				oRegionVal = sap.ui.getCore().byId("idRegion").getSelectedItem().getText();
			if ((oStoreVal === "") && (oVendor === "") && (oOrder === "") && (oDistrictVal.slice(0, 6) === "Select") && (oRegionVal.slice(0, 6) ===
					"Select")) {
				oSearchBtn.setEnabled(false);
			}
		},
		// Enable search button with vendor selection
		oVendorSelected: function (oEvent) {
			sap.ui.getCore().byId("searchButton").setEnabled(true);

		},
		//Refine selection feed
		handleVendorSuggest: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = [];
			var bFilters = [];
			if (sTerm) {
				aFilters.push(new Filter("Name1", sap.ui.model.FilterOperator.StartsWith, sTerm));
				var oResult = oEvent.getSource().getBinding("suggestionRows").filter(aFilters);
				if (oResult.aIndices.length) {
					if (oResult.aIndices.length !== 0) {
						oEvent.getSource().getBinding("suggestionRows").filter(aFilters);
					} else {
						aFilters.push(new Filter("Lifnr", sap.ui.model.FilterOperator.StartsWith, sTerm));
						oEvent.getSource().getBinding("suggestionRows").filter(aFilters);
					}
				} else {
					bFilters.push(new Filter("Lifnr", sap.ui.model.FilterOperator.StartsWith, sTerm));
					oEvent.getSource().getBinding("suggestionRows").filter(bFilters);
				}
			}
			// oEvent.getSource().getBinding("suggestionItems").filter(aFilters);
			// oEvent.getSource().getBinding("suggestionRows").filter(aFilters);
		},
		handleStoreSuggest: function (oEvent) {
			var sTerm = oEvent.getParameter("suggestValue");
			var aFilters = [];
			aFilters.push(new Filter("Site", sap.ui.model.FilterOperator.StartsWith, sTerm));
			oEvent.getSource().getBinding("suggestionItems").filter(aFilters);

		},

		// Enable/Disable search button with input
		onOrderInput: function (oEvent) {
			var oOrder = sap.ui.getCore().byId("idOrder").getValue();
			var oVendor = sap.ui.getCore().byId("idVendor").getValue();
			var oStoreVal = sap.ui.getCore().byId("idStore").getValue();
			var oSearchBtn = sap.ui.getCore().byId("searchButton"),
				oDistrictVal = sap.ui.getCore().byId("idDistrict").getSelectedItem().getText(),
				oRegionVal = sap.ui.getCore().byId("idRegion").getSelectedItem().getText();
			if ((oStoreVal === "") && (oVendor === "") && (oOrder === "") && (oDistrictVal.slice(0, 6) === "Select") && (oRegionVal.slice(0,
						6) ===
					"Select")) {
				oSearchBtn.setEnabled(false);
			} else {
				oSearchBtn.setEnabled(true);
			}

		},

		onMasterRTVCratePress: function () {
			if (this.getView().getParent().getParent().getCurrentDetailPage().getId().indexOf("Verify") !== -1) {
				var controller = this;
				var dialog = new Dialog({
					title: this.getResourceBundle().getText("Warning"),
					type: "Message",
					state: "Warning",
					content: new Text({
						text: this.getResourceBundle().getText("FromVerifyToCreate")
					}),
					beginButton: new Button({
						text: this.getResourceBundle().getText("Yes"),
						press: function () {
							dialog.close();
							controller.getCreateDialog().open();
						}
					}),
					endButton: new Button({
						text: this.getResourceBundle().getText("Cancel"),
						press: function () {
							dialog.close();
							controller.byId("searchField").focus();
							__controller__.onVKeypadHide();
						}
					}),
					afterClose: function () {
						dialog.destroy();
					}
				});
				if(sap.ui.getCore().byId("idDReasonCode")){
				sap.ui.getCore().byId("idDReasonCode").setEnabled(false);
				}
				dialog.open();
				return;
			}

			this.getCreateDialog().open();
		},
		onDialogRTVBackPress: function (evt) {
			this.beforeOpenDialog();
			this.getCreateDialog().close();
			this.byId("searchField").focus();
			__controller__.onVKeypadHide();
		},
		onArticleChange: function (evt) {
			var articleFld = evt.getSource(),
				liveValue = articleFld.getValue();
			if (isNaN(liveValue) || liveValue === "") {
				articleFld.setValueState(ValueState.Error).setValueStateText("").focus();
			} else {
				articleFld.setValueState(ValueState.None).setValueStateText("").focus();
			}
			if (liveValue.length !== 0) {
				this._oDialog.setBusy(true);
				articleFld.setValue(liveValue);
				this.callArticleSearch();
			} else {
				articleFld.setValueState(ValueState.Error).setValueStateText("").focus();
			}
		},
		onArticleLiveChange: function (evt) {
			var fld = evt.getSource(),
				value = evt.getParameter("value").replace(/[^\d]/g, "");
			fld.updateDomValue(value);
			fld.setValueState(ValueState.None);
		},
		callArticleSetOData: function (successFnc, errorFnc) {
			var that = this,
				oModel = this.getModel(),
				articleFld = sap.ui.getCore().byId("idDArticle"),
				article = articleFld.getValue();
			var aFilters = [
				new Filter("SEARCH_UPC_ART", "EQ", article),
				new Filter("WERKS", "EQ", ""),
				//changes for siteID
				new Filter("TRANS", "EQ", "01")
			];
			that._oDialog.setBusy(true);
			this.getModel().read("/ArticleProcessSet", {
				filters: aFilters,
				urlParameters: {
					"$expand": "reason_cdset,upcset"
				},
				success: function (oData) {
					that._oDialog.setBusy(false);
					articleFld.setValueState(ValueState.None).setValueStateText("");
					// setting additional details in articleModel
					for (var i = 0; i < oData.results.length; i++) {
						oData.results[i].Retail = "";
						oData.results[i].OnlineOnly = false;
						oData.results[i].RGA = "";
						oData.results[i].Attachment = "";
						oData.results[i].RtvLoc = "";
						oData.results[i].Comments = "";
						oData.results[i].Valid = true;
					}
					that.getModel().checkUpdate(true);
					successFnc(oData);
					sap.ui.getCore().byId("idDReasonCode").setEnabled(true);
				},
				error: function (oError) {
					that._oDialog.setBusy(false);
					articleFld.setValueState(ValueState.Error).setValueStateText("").focus();
					errorFnc(oError);
				}
			});
		},
		callArticleSearch: function () {
			var that = this,
				successFnc = function (oData) {
					if (oData.results[0].MSG_TYPE === "E") {
						MessageToast.show(that.getResourceBundle().getText("EnterValidArticleUpcNumber"));
					} else {
						that.createArticleModel({
							Articles: oData.results,
							ReasonCodeSet: oData.results[0].reason_cdset.results
						});
						jQuery.sap.delayedCall(500, sap.ui.getCore().byId("addButton"), sap.ui.getCore().byId("addButton").focus);
					}
				},
				errorFnc = function (oError) {
					that.createArticleModel();
					try {
						var paresedError = JSON.parse(oError.responseText).error.message.value;
						MessageToast.show(paresedError);
					} catch (err) {
						MessageToast.show(that.getResourceBundle().getText("EnterValidArticleUpcNumber"));
					}
				};
			this.callArticleSetOData(successFnc, errorFnc);
		},
		onDialogRTVCreatePress: function (evt) {
			var article = sap.ui.getCore().byId("idDArticle");
			var reasonCode = sap.ui.getCore().byId("idDReasonCode");
			if (article.getValue().length < 10) {
				article.setValueStateText("").setValueState(sap.ui.core.ValueState.Error);
				MessageToast.show(this.getResourceBundle().getText("EnterValidArticleUpcNumber"));
				return;
			}
			if (reasonCode.getSelectedKey() === "" || article.getValueState() === "Error") {
				return;
			}
			var that = this,
				bReplace = !Device.system.phone,
				successFnc = function (oData) {
					that.byId("idCreateRTVBtn").setEnabled(false);
					that._oDialog.close();
					that.byId("list").removeSelections(true);
					that.byId("searchField").setValue("");
					var werks = that.getView().getModel("articleModel").getData().Articles[0].WERKS;
					that.getRouter().navTo("createDetail", {
						Werks: werks,
						article: article.getValue(),
						reasonCd: reasonCode.getSelectedKey()
					}, bReplace);
				};
			var articleFromModel = this.getView().getModel("articleModel").getData().Article;
			var articleFromUi = article.getValue().trim();
			if (articleFromUi.trim() !== articleFromModel) {
				this.callArticleSetOData(successFnc, $.noop);
			}
			successFnc();
		},
		removeLeadingZeroes: function (value) {
			var valueSerach = value ? value.replace(/^0+/, "") : "";
			return valueSerach;
		},
		DateFormat: DateFormat.getDateInstance({
			pattern: "MM/dd/yyyy"
		}),
		Date2NumFormat: DateFormat.getDateInstance({
			pattern: "yyyyMMdd"
		}),
		formatDate: function (value) {
			if (!value) {
				return "";
			} else {
				var oLength = value.length;
				var oDate;
				if (oLength === 10) {
					oDate = value.slice(5, 7) + "/" + value.slice(8, 10) + "/" + value.slice(0, 4);
				} else {
					oDate = value.slice(4, 6) + "/" + value.slice(6, 8) + "/" + value.slice(0, 4);
				}
				return oDate; // return this.DateFormat.format(new Date(value.getTime() + new Date().getTimezoneOffset() * 60000));
			}
		},
		dueDateStatus: function (value) {
			if (!value) {
				return ValueState.None;
			} else if (value !== "00000000") {
				// var todayAsInt = parseInt(this.Date2NumFormat.format(new Date()));
				var todayAsString = this.Date2NumFormat.format(new Date());
				var bLength = todayAsString.length;
				var bDate;
				if (bLength === 10) {
					bDate = todayAsString.slice(5, 7) + "/" + todayAsString.slice(8, 10) + "/" + todayAsString.slice(0, 4);
				} else {
					bDate = todayAsString.slice(4, 6) + "/" + todayAsString.slice(6, 8) + "/" + todayAsString.slice(0, 4);
				}
				// var dueDateAsInt = parseInt(this.Date2NumFormat.format(new Date(Date.parse(value) + new Date().getTimezoneOffset() * 60000)));
				var aLength = value.length;
				var aDate;
				if (aLength === 10) {
					aDate = value.slice(5, 7) + "/" + value.slice(8, 10) + "/" + value.slice(0, 4);
				} else {
					aDate = value.slice(4, 6) + "/" + value.slice(6, 8) + "/" + value.slice(0, 4);
				}
				var today = new Date(bDate);
				var dueDate = new Date(aDate);
				if (dueDate.getTime() <= today.getTime()) {
					return ValueState.Error;
				} // if (dueDateAsInt <= todayAsInt) {
				// 	return ValueState.Error;
				// }
			} else {
				return ValueState.None;
			}
		},
		onSearch: function (oEvent) {
			walkThroughUI(this.byId("list"), includeByClass(sap.m.ObjectListItem, includeByData("search", "X", function (element) {
				element.data("search", undefined);
			})));
			if (oEvent.getParameters().refreshButtonPressed) {
				this.onRefresh();
				return;
			}
			var messageText = "FromVerifyToVerify";
			if (this.getView().getParent().getParent().getCurrentDetailPage().getId().indexOf("createDetail") !== -1) {
				messageText = "FromCreateToVerify";
			} else if (this.getView().getParent().getParent().getCurrentDetailPage().getId().indexOf("notFound") !== -1 || this.getView().getParent()
				.getParent().getCurrentDetailPage().getId().indexOf("detailObjectNotFound") !== -1) {
				messageText = "";
			}
			var sQuery = oEvent.getParameter("query").trim();
			var controller = this;
			if (messageText !== "" && messageText !== "FromVerifyToVerify") {
				var dialog = new Dialog({
					title: this.getResourceBundle().getText("Warning"),
					type: "Message",
					state: "Warning",
					content: new Text({
						text: this.getResourceBundle().getText(messageText)
					}),
					beginButton: new Button({
						text: this.getResourceBundle().getText("Yes"),
						press: function () {
							dialog.close();
							controller.byId("searchField").setValue("");
							controller.byId("idCreateRTVBtn").setEnabled(true);
							controller.getQuery(sQuery, controller);
						}
					}),
					endButton: new Button({
						text: this.getResourceBundle().getText("Cancel"),
						press: function () {
							dialog.close();
						}
					}),
					afterClose: function () {
						dialog.destroy();
					}
				});
				dialog.open();
			} else {
				controller.getQuery(sQuery, controller);
			}
			this.byId("searchField").setValue("");
			jQuery.sap.delayedCall(0, this.byId("list"), this.byId("list").rerender);
		},
		getQuery: function (sQuery, controller) {
			if (sQuery) {
				var regex = new RegExp(sQuery, "i");
				var items = controller.byId("list").getItems();
				if (items) {
					var __item__;
					items.forEach(function (item) {
						if (item) {
							var __object__ = item.getBindingContext("oDataModel").getObject();
							if (__object__.LabelNum) {
								if (sQuery === __object__.LabelNum)
								//if( __object__.LabelNum .match(regex) )
								{
									if (!__item__)
										__item__ = item;
								}
							}
						}
					});
					if (__item__) {
						if (__item__ !== controller.byId("list").getSelectedItem()) {
							controller._showDetail(__item__);
							controller.byId("list").setSelectedItem(__item__, true);
							controller.byId("MasterPage").scrollToElement(__item__, 500);
						}
					} else {
						var oSiteId = controller.siteId;
						this.fetchLabel(sQuery, oSiteId); // MessageToast.show(controller.getResourceBundle().getText("InvalidLabel", [sQuery]));
						// if (!Device.system.phone) {
						// 	controller.getRouter().navTo("verifyNotAvailable", {}, true);
						// }
						// controller.labelNum = "";
						// controller.syncSelection();
					}
				}
			}
		},
		fetchLabel: function (sQuery, oSiteId) {
			var oDataModel = this.getModel();
			var that = this;
			var oPath = "/VerifySet(LabelNum='" + sQuery + "',Werks='" + oSiteId + "')";
			sap.ui.core.BusyIndicator.show(true);
			oDataModel.read(oPath, {
				success: function (odata, oResponse) {
					sap.ui.core.BusyIndicator.hide(true);
					if (odata.LabelNum === "") {
						MessageToast.show(that.getResourceBundle().getText("InvalidLabel", [sQuery]));
					} else {
						var oModel = that.getModel("oSearchModel");
						oModel.setProperty("/VerifySet", odata);
						that._showDetail(sQuery, that.siteId);
					}
				},
				error: function (oError) {
					sap.ui.core.BusyIndicator.hide(true);
					MessageToast.show(that.getResourceBundle().getText("InvalidLabel", [sQuery]));
				}
			});
		},
		onPressIcon: function (evt) {
			// var imageSrc = evt.getSource().getBindingContext("verify").getObject().Image;
			var imageSrc = evt.getSource().getParent().getBindingContext("oDataModel").getObject().Image;
			this.oOverlayContainer = new sap.ui.ux3.OverlayContainer({
				"openButtonVisible": false
			});
			this.oOverlayContainer.removeStyleClass("sapUiShd");
			this.oOverlayContainer.addStyleClass("background");
			var device = sap.ui.Device.system;
			var deviceWidth = $(window).width();
			var deviceHeight = $(window).height();
			var imgWidth, imgHeight = 0;
			// Converting to String as system below accepting in string format
			if (deviceWidth !== undefined && deviceWidth !== null) {
				imgWidth = deviceWidth.toString();
			}
			if (deviceHeight !== undefined && deviceHeight !== null) {
				var imgHeightMob = deviceHeight - 50;
				imgHeight = deviceHeight * 0.8;
				imgHeight = imgHeight.toString();
				imgHeightMob = imgHeight.toString();
			}
			if (device.desktop) {
				imgWidth = deviceWidth * 0.65;
				this.oOverlayContainer.addStyleClass("customoverlying");
				var desktopImg = new sap.m.Image({
					"src": imageSrc,
					"height": imgHeight + "px",
					"width": imgWidth + "px"
				});
				desktopImg.addStyleClass("desktopImg");
				this.oOverlayContainer.addContent(desktopImg);
			} else {
				var mobileImg = new sap.m.Image({
					"src": imageSrc,
					"densityAware": false,
					"height": imgHeightMob + "px",
					"width": imgWidth + "px"
				});
				mobileImg.addStyleClass("mobileImg");
				this.oOverlayContainer.addContent(mobileImg);
			}
			// Open the overlay
			if (!this.oOverlayContainer.isOpen()) {
				this.oOverlayContainer.open();
			}
		},
		_AuthorizationAccess: function (oItem) {
			var oModel = this.getModel("oDataModel");
			var createRTVBtn = this.byId("idCreateRTVBtn");
			var oFilterBtn = this.byId("filter_btn");
			var oAuthModel = this.getOwnerComponent().getModel("oAuthModel"),
				oAuthData = oAuthModel.getData();
			if (!oAuthData.results) {
				var that = this;
				sap.ui.core.BusyIndicator.show();
				oModel.read("/UserAuthSet", {
					success: function (oData, response) {
						oAuthModel.setData(oData.results[0]);
						createRTVBtn.setVisible(oData.results.some(function (item) {
							return item.Create === "Y";
						}));

						oFilterBtn.setVisible(oData.results.some(function (item) {
							return item.PSC_User === "Y";
						}));

						if (oFilterBtn.getVisible() === true) {

							that.getStoreheireracy();
							that.sOAVendorData();
						}

						// sap.ui.core.BusyIndicator.hide();
						if (oItem) {
							that._showDetail(oItem);
						}

					},
					error: function (oError) {
						that.createRTVBtn.setVisible(false);
						sap.ui.core.BusyIndicator.hide();
						if (oItem) {
							that._showDetail(oItem);
						}
					}
				});
			} else {

				this._showDetail(oItem);
			}
		},
		getStoreheireracy: function () {
			var oModel = this.getModel("oDataModel");
			var StoreHierarcy = this.getOwnerComponent().getModel("StoreHierarcy");
			// sPath = "/StoreHierarchySet?&$expand=Store,Dist,Region";
			var that = this;
			oModel.read("/StoreHierarchySet", {
				urlParameters: {
					"$expand": "Store,Dist,Region"
				},
				success: function (oData, response) {
					var oRegionModel = that.getOwnerComponent().getModel("oRegionModel"),
						oDistrictModel = that.getOwnerComponent().getModel("oDistrictModel"),
						oStoreModel = that.getOwnerComponent().getModel("oStoreModel");
					// oRegion,
					// oDistrict,
					// oStore;
					sap.ui.core.BusyIndicator.hide();
					StoreHierarcy.setData(oData);

					oRegionModel.setData(oData.results[0].Region);
					oDistrictModel.setData(oData.results[0].Dist);
					oStoreModel.setData(oData.results[0].Store);

				},
				error: function (oError) {
					sap.ui.core.BusyIndicator.hide();
					MessageToast.show(that.getResourceBundle().getText("StoreHireracy"));
				}
			});

		},

		sOAVendorData: function (oEvent) {
			var oModel = this.getModel("oDataModel");
			var sOAVendor = this.getOwnerComponent().getModel("sOAVendor");
			var that = this;
			oModel.read("/OA_VENDORSet", {
				success: function (oData, response) {
					sap.ui.core.BusyIndicator.hide();
					sOAVendor.setData(oData);
				},
				error: function (oError) {
					sap.ui.core.BusyIndicator.hide();
					MessageToast.show(that.getResourceBundle().getText("StoreHireracy"));
				}
			});

		},

		_showDetail: function (oItem, oSiteId) {
				// this.getModel("verify").resetChanges();
				this.getModel("oDataModel").resetChanges();
				var oSearch, verifyObject, oWerks, oLabelNum, bReplace = !Device.system.phone;
				// var verifyObject = oItem.getBindingContext("verify").getObject(),
				if (!oSiteId) {
					verifyObject = oItem.getBindingContext("oDataModel").getObject();
					oWerks = verifyObject.Werks;
					oLabelNum = verifyObject.LabelNum;
					oSearch = false;
				} else {
					oWerks = oSiteId;
					oLabelNum = oItem;
					oSearch = true;
				}
				var that = this;
				jQuery.sap.delayedCall(10, that, function () {
					that.getModel("appView").setProperty("/busy", true);
				});
				this.getRouter().navTo("verify", {
					Werks: oWerks,
					LabelNum: oLabelNum,
					Search: oSearch
				}, bReplace);
			}
			/**
			 *@memberOf com.hd.rtvcreate.controller.Master
			 */

	});
});