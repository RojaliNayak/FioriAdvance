sap.ui.define([
	"YRTV_ONE_TILE/YRTV_ONE_TILE/controller/CreateVerify/DetailBaseController"
], function(DetailBaseController) {
	"use strict";

	return DetailBaseController.extend("YRTV_ONE_TILE.YRTV_ONE_TILE.controller.CreateVerify.CreateDetail", {
	});
});