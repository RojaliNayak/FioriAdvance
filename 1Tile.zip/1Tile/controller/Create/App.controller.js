sap.ui.define([
	"YRTV_ONE_TILE/YRTV_ONE_TILE/controller/CreateVerify/BaseController",
	"sap/ui/model/json/JSONModel"
], function (BaseController, JSONModel) {
		"use strict";
		return BaseController.extend("YRTV_ONE_TILE.YRTV_ONE_TILE.controller.CreateVerify.App", {

			onInit : function () {
				
				this.getOwnerComponent().createVerifyComp();
				
				var oListSelector 		= this.getOwnerComponent().oListSelector;

				oListSelector.attachListSelectionChange(function () {
					this.byId("idAppControl").hideMaster();
				}, this);
				this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());
			}
		});
	}
);
