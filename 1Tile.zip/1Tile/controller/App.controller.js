sap.ui.define([
	'YRTV_ONE_TILE/YRTV_ONE_TILE/controller/BaseController',
	'sap/ui/core/mvc/Controller',
	'sap/m/ResponsivePopover',
	'sap/m/MessagePopover',
	'sap/m/ActionSheet',
	'sap/m/Button',
	'sap/m/Link',
	'sap/m/NotificationListItem',
	'sap/m/MessagePopoverItem',
	'sap/ui/core/CustomData',
	'sap/m/MessageToast',
	'sap/ui/Device',
	'sap/m/library'
], function (BaseController,Controller, ResponsivePopover, MessagePopover, ActionSheet, Button, Link, NotificationListItem,
	MessagePopoverItem, CustomData, MessageToast, Device, mobileLibrary) {
	"use strict";

	return BaseController.extend("YRTV_ONE_TILE.YRTV_ONE_TILE.controller.App", {
		
		_bExpanded: true,
		
		onInit: function () {
			$.sap.appView = this.getView();
			//this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());

			// // if the app starts on desktop devices with small or meduim screen size, collaps the sid navigation
			// if (Device.resize.width <= 1024) {
			// 	this.onSideNavButtonPress();
			// }

			// Device.media.attachHandler(this._handleWindowResize, this);
			// this.getRouter().attachRouteMatched(this.onRouteChange.bind(this));
		},
		
		// onExit: function() {
		// 	// Device.media.detachHandler(this._handleWindowResize, this);
		// }
		
		// onRouteChange: function (oEvent) {
		// 	this.getModel('menu').setProperty('/selectedKey', oEvent.getParameter('name'));

		// 	if (Device.system.phone) {
		// 		this.onSideNavButtonPress();
		// 	}
		// },
		
		// itemSelection: function(oEvent){
			
		// 	var selected = oEvent.getParameter("item").getProperty("key");
			
		// 	switch(selected) {
		// 	  case "":
		// 	  	//Home
			  	
		// 	  case "BackToSearch":
			  	
		//   	  case "VerifyItems":
			  		
		// 	  case "Shipment":
			  			
		// 	  case "Destroy":
			  				
		//       case "Buyback":
			  					
		// 	  case "Awaiting":
			  						
		// 	  case "CageAudit":
			  							
		// 	  case "CageReport":
			  		
		// 	  case "MET":

			  	
		// 	  default:
		// 	}
			
		// },
		
		// onSideNavButtonPress: function() {
		// 	//var oToolPage = this.byId("App");
		// 	//var bSideExpanded = oToolPage.getSideExpanded();
		// 	//this._setToggleButtonTooltip(bSideExpanded);
		// 	//oToolPage.setSideExpanded(!oToolPage.getSideExpanded());
		// },
		
		// _setToggleButtonTooltip : function(bSideExpanded) {
		// 	var oToggleButton = this.byId('sideNavigationToggleButton');
		// 	// this.getBundleText(bSideExpanded ? "expandMenuButtonText" : "collpaseMenuButtonText").then(function(sTooltipText){
		// 		oToggleButton.setTooltip("Expand");
		// 	// });
		// },
		
		// getBundleText: function(sI18nKey, aPlaceholderValues){
		// 	var sText = this.getView().getModel("i18n").getResourceBundle().getText(sI18nKey);
		// 	return sText;
		// 	// return this.getBundleTextByModel(sI18nKey, this.getView().getModel("i18n"), aPlaceholderValues);
		// },
		
		// // getBundleTextByModel: function(sI18nKey, oResourceModel, aPlaceholderValues){
		// // 	return oResourceModel.getResourceBundle().then(function(oBundle){
		// // 		return oBundle.getText(sI18nKey, aPlaceholderValues);
		// // 	});
		// // },
		
		// _handleWindowResize: function (oDevice) {
		// 	if ((oDevice.name === "Tablet" && this._bExpanded) || oDevice.name === "Desktop") {
		// 		this.onSideNavButtonPress();
		// 		// set the _bExpanded to false on tablet devices
		// 		// extending and collapsing of side navigation should be done when resizing from
		// 		// desktop to tablet screen sizes)
		// 		this._bExpanded = (oDevice.name === "Desktop");
				
		// 		// set the _bExpanded to false on tablet devices
		// 		// extending and collapsing of side navigation should be done when resizing from
		// 		// desktop to tablet screen sizes)
		// 	}
		// }
	});
});