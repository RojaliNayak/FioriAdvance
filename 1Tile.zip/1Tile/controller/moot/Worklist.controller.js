sap.ui.define([
	"YRTV_ONE_TILE/YRTV_ONE_TILE/controller/METWorklist/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"YRTV_ONE_TILE/YRTV_ONE_TILE/model/METWorklist/formatter",
	"sap/ui/model/Filter",
	"sap/ui/core/format/DateFormat",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/odata/OperationMode"
], function (BaseController, JSONModel, History, formatter, Filter, DateFormat, FilterOperator, OperationMode) {
	"use strict";

	return BaseController.extend("YRTV_ONE_TILE.YRTV_ONE_TILE.controller.METWorklist.Worklist", {

		formatter: formatter,

		DateFormat: DateFormat.getDateInstance({
			pattern: "MM/dd/yyyy"
		}),

		Date2NumFormat: DateFormat.getDateInstance({
			pattern: "yyyyMMdd"
		}),

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function () {

			//APP

			var oViewModel,
				fnSetAppNotBusy,
				iOriginalBusyDelay = this.getView().getBusyIndicatorDelay();

			oViewModel = new JSONModel({
				busy: true,
				delay: 0
			});
			this.setModel(oViewModel, "appView");

			fnSetAppNotBusy = function () {
				oViewModel.setProperty("/busy", false);
				oViewModel.setProperty("/delay", iOriginalBusyDelay);
			};

			//End APP

			this.worksheet = "";

			var oViewModel,
				iOriginalBusyDelay,
				oTable = this.byId("table");

			window._metSearch = "";

			// Put down worklist table's original value for busy indicator delay,
			// so it can be restored later on. Busy handling on the table is
			// taken care of by the table itself.
			iOriginalBusyDelay = oTable.getBusyIndicatorDelay();
			// keeps the search state
			this._oTableSearchState = [];

			// Model used to manipulate control states
			oViewModel = new JSONModel({
				worklistTableTitle: this.getOwnerComponent().getModel("METi18n").getResourceBundle().getText("worklistTableTitle"),
				saveAsTileTitle: this.getOwnerComponent().getModel("METi18n").getResourceBundle().getText("worklistViewTitle"),
				shareOnJamTitle: this.getOwnerComponent().getModel("METi18n").getResourceBundle().getText("worklistViewTitle"),
				shareSendEmailSubject: this.getOwnerComponent().getModel("METi18n").getResourceBundle().getText("shareSendEmailWorklistSubject"),
				shareSendEmailMessage: this.getOwnerComponent().getModel("METi18n").getResourceBundle().getText("shareSendEmailWorklistMessage", [
					location.href
				]),
				tableNoDataText: this.getOwnerComponent().getModel("METi18n").getResourceBundle().getText("tableNoDataText"),
				tableBusyDelay: 0
			});

			this.setModel(oViewModel, "worklistView");

			// Make sure, busy indication is showing immediately so there is no
			// break after the busy indication for loading the view's meta data is
			// ended (see promise 'oWhenMetadataIsLoaded' in AppController)
			oTable.attachEventOnce("updateFinished", function () {
				// Restore original busy indicator delay for worklist's table
				oViewModel.setProperty("/tableBusyDelay", iOriginalBusyDelay);
			});

			this.getRouter().getRoute("METWorklist").attachPatternMatched(this._onObjectMatched, this);

			// var todayAsInt = Date.parse(new Date(new Date().getTime())); //parseInt(todayAsStr);
			var dueDateDelegate = {
				onAfterRendering: function () {
					var dueDateValue = this.getBindingContext().getObject().DUE_DATE;
					var bLength = dueDateValue.length;
					var bDate;
					if (bLength === 10) {
						bDate = dueDateValue.slice(5, 7) + "/" + dueDateValue.slice(8, 10) + "/" + dueDateValue.slice(0, 4);
					} else {
						bDate = dueDateValue.slice(4, 6) + "/" + dueDateValue.slice(6, 8) + "/" + dueDateValue.slice(0, 4);
					}
					var aDueDate = new Date(bDate);
					var oToday = new Date();
					if (aDueDate <= oToday) {
						// if (Date.parse(dueDateValue) <= todayAsInt) {
						if (!this.hasStyleClass('dueDateColor')) {
							this.addStyleClass('dueDateColor');
						}
					} else {
						this.removeStyleClass("dueDateColor");
					}
				}
			};
			var dueDate = this.byId("DueDate");
			dueDate.addDelegate(dueDateDelegate, false, dueDate, true);

			var labelNumberDelegate = {
				onAfterRendering: function () {
					var labelNum = this.getBindingContext().getObject().LABEL_NUM;
					this.removeStyleClass("redLabelWorklist");
					this.removeStyleClass("yellowLabelWorklist");
					this.removeStyleClass("greenLabelWorklist");
					this.removeStyleClass("whiteLabelWorklist");
					if (labelNum.indexOf('98181') === 0) {
						this.addStyleClass('redLabelWorklist');
					} else if (labelNum.indexOf('98182') === 0) {
						this.addStyleClass('yellowLabelWorklist');
					} else if (labelNum.indexOf('98183') === 0) {
						this.addStyleClass('greenLabelWorklist');
					} else if (labelNum.indexOf('98184') === 0) {
						this.addStyleClass('whiteLabelWorklist');
					}
				}
			};
			var labelNumber = this.byId("TextLabel");
			labelNumber.addDelegate(labelNumberDelegate, false, labelNumber, true);
			this._AuthorizationAccess();
			this._domainData();
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		_onObjectMatched: function (oEvent) {
			var oModel = this.getModel();
			oModel.setDefaultCountMode(sap.ui.model.odata.CountMode.None);
			// var oAuthModel = this.getOwnerComponent().getModel("oAuthModel"),
			// 	sData = oAuthModel.getData();
			// oModel.read("/MetLabelSet", {
			// 	success: function (oData) {}
			// });

			this.byId("table").rerender();

			if (this.getOwnerComponent()._backAfterLabeComplete === true && window._metSearch.length === 17) {
				window._metSearch = "";
				this.byId("table").unbindItems();
			}
			this.getOwnerComponent()._backAfterLabeComplete = false;

			this._search(window._metSearch);
			// }.bind(this));

			var field = this.byId("idSearchField");
			field.setValue("");
			field.rerender();

			jQuery.sap.delayedCall(500, this, function () {
				field.focus();
				this.onVKeypadHide();
			});
		},

		/**
		 * Triggered by the table's 'updateFinished' event: after new table
		 * data is available, this handler method updates the table counter.
		 * This should only happen if the update was successful, which is
		 * why this handler is attached to 'updateFinished' and not to the
		 * table's list binding's 'dataReceived' method.
		 * @param {sap.ui.base.Event} oEvent the update finished event
		 * @public
		 */
		onUpdateFinished: function (oEvent) {
			// update the worklist's object counter after the table update
			var sTitle,
				oTable = oEvent.getSource(),
				iTotalItems = oEvent.getParameter("total"),
				met = this.getModel("APP").getProperty("/met");
			// only update the counter if the length is final and
			// the table is not empty

			if (this.getOwnerComponent().metGetSite() === "" && this.byId("table").getItems().length > 0) {
				var werks = this.getModel().getProperty(this.byId("table").getItems()[0].getBindingContextPath()).WERKS;
				this.getOwnerComponent().metSetSite(werks);
			}

			if (met === "X") {
				if (iTotalItems && oTable.getBinding("items").isLengthFinal()) {
					sTitle = this.getOwnerComponent().getModel("METi18n").getResourceBundle().getText("worklistTableTitleCountMet", [iTotalItems]);
					this.getOwnerComponent().googleAnalyticUpdate({
						page: "MET Labels",
						site: werks
					}); //Google Analytics
				} else {
					sTitle = this.getOwnerComponent().getModel("METi18n").getResourceBundle().getText("worklistTableTitleMet");
					this.getOwnerComponent().googleAnalyticUpdate({
						page: "MET Worksheet",
						site: werks
					}); //Google Analytics
				}
			} else {
				if (iTotalItems && oTable.getBinding("items").isLengthFinal()) {
					if (iTotalItems === 0) {
						this.worksheet = "";
					}
					sTitle = this.getOwnerComponent().getModel("METi18n").getResourceBundle().getText("worklistTableTitleCount", [this.worksheet,
						iTotalItems
					]);
				} else {
					sTitle = this.getOwnerComponent().getModel("METi18n").getResourceBundle().getText("worklistTableTitle");
				}
			}

			this.getModel("worklistView").setProperty("/worklistTableTitle", sTitle);

			if (iTotalItems === 1 && window._metNavBack !== 'N' && this._seachButtonPressed === 'X') {
				this._seachButtonPressed = '';
				var item = oTable.getItems()[0];
				this._showObject(item);
			}
			this.byId("idSearchField").focus();
			this.onVKeypadHide();
		},

		/**
		 * Event handler when a table item gets pressed
		 * @param {sap.ui.base.Event} oEvent the table selectionChange event
		 * @public
		 */
		onPress: function (oEvent) {
			// The source is the list item that got pressed
			this._showObject(oEvent.getSource());
		},
		onLabelScan: function (oEvent) {
			if (oEvent.getSource().getValue().trim().length >= 17) {
				this.onSearch(oEvent);
			}
			// oEvent.getSource().setValue("");
		},
		/**
		 * Event handler for navigating back.
		 * It there is a history entry or an previous app-to-app navigation we go one step back in the browser history
		 * If not, it will navigate to the shell home
		 * @public
		 */
		onNavBack: function () {
			if (sap.ushell && sap.ushell.Container && sap.ushell.Container.getService) {
				var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
				oCrossAppNavigator.toExternal({
					target: {
						semanticObject: "#"
					}
				});
			} else {
				history.go(-1);
			}
		},

		onSearch: function (oEvent) {
			var appModel = this.getModel("APP");

			if (oEvent.getParameters().refreshButtonPressed) {
				// Search field's 'refresh' button has been pressed.
				// This is visible if you select any master list item.
				// In this case no new search is triggered, we only
				// refresh the list binding.
				this.onRefresh();

				appModel.setProperty("/search", "");
			} else {
				var val = oEvent.getSource().getValue();
				oEvent.getSource().setValue(val);
				oEvent.getSource().rerender();
				this._seachButtonPressed = 'X';
				this._search(val);

				appModel.setProperty("/search", val);

				oEvent.getSource().setValue("");
			}
		},

		_search: function (sSearch) {
			var val = "";
			if (sSearch) {
				val = sSearch.replace(/\s/g, "");
			} else {
				val = sSearch;
			}
			var oTableSearchState = [];
			var sQuery = val;
			window._metSearch = val;

			if (sQuery && sQuery.length > 0) {
				this.worksheet = sQuery;

				var met = this.getModel("APP").getProperty("/met"),
					isITSupport = this.getModel("APP").getProperty("/isITSupport"),
					is3rdParty = this.getModel("APP").getProperty("/is3rdParty");

				//It is not MET user so we perform server side search
				if (isITSupport || is3rdParty) {
					oTableSearchState = [
						new Filter("SEARCH", FilterOperator.EQ, sQuery)
					];
				} else {
					//For MET user we perform client side search
					//An array of other filters named filters and a Boolean flag and that
					//specifies whether to combine the filters with an AND (true) or an OR (false) operator.
					oTableSearchState = new Filter(
						[
							new Filter("LABEL_NUM", FilterOperator.Contains, sQuery),
							new Filter("LIFNR_NAME", FilterOperator.Contains, sQuery),
							new Filter("LIFNR", FilterOperator.Contains, sQuery)

						], false);

				}
			}
			this._applySearch(oTableSearchState);
		},

		onSearchChange: function (oEvent) {
			var val = sap.ui.getCore().byId("searchField").getProperty("value");
			val = val.replace(/\s/g, "");
			sap.ui.getCore().byId("searchField").setProperty("value", val);
		},

		/**
		 * Event handler for refresh event. Keeps filter, sort
		 * and group settings and refreshes the list binding.
		 * @public
		 */
		onRefresh: function () {
			var oTable = this.byId("table");
			oTable.getBinding("items").refresh();
		},

		/* =========================================================== */
		/* internal methods                                            */
		/* =========================================================== */

		/**
		 * Shows the selected item on the object page
		 * On phones a additional history entry is created
		 * @param {sap.m.ObjectListItem} oItem selected Item
		 * @private
		 */
		_showObject: function (oItem) {
			this.getRouter().navTo("METobject", {
				objectId: oItem.getBindingContext().getProperty("LABEL_NUM"),
				site: oItem.getBindingContext().getProperty("WERKS"),
				region: oItem.getBindingContext().getProperty("REGION") || "XX"
			});
		},

		/**
		 * Internal helper method to apply both filter and search state together on the list binding
		 * @param {object} oTableSearchState an array of filters for the search
		 * @private
		 */
		_applySearch: function (oTableSearchState) {
			var oTable = this.byId("table"),
				oViewModel = this.getModel("worklistView"),
				bindingInfo = oTable.getBindingInfo("items");

			if (!bindingInfo || !bindingInfo.path) {
				var isMET = this.getModel("APP").getProperty("/isMET"),
					isITSupport = this.getModel("APP").getProperty("/isITSupport"),
					is3rdParty = this.getModel("APP").getProperty("/is3rdParty");

				bindingInfo = {
					filters: oTableSearchState,
					path: "/MetLabelSet",
					template: this.byId("WorklistColumnListItem")
				};

				if (!isITSupport && !is3rdParty && isMET) {
					bindingInfo.parameters = {
						operationMode: OperationMode.Client
					};
				}

				oTable.bindItems(bindingInfo);
			} else {
				oTable.getBinding("items").filter(oTableSearchState, "Application");
			}

			// changes the noDataText of the list in case there are no filter results
			if (oTableSearchState.length !== 0) {
				oViewModel.setProperty("/tableNoDataText", this.getOwnerComponent().getModel("METi18n").getResourceBundle().getText(
					"worklistNoDataWithSearchText"));
			}
		},

		onBeforeRendering: function () {
			var field = this.byId("idSearchField");
			var val = field.getValue();
			val = val.replace(/\s/g, "");
			field.setValue(val);
			field.rerender();
		},
		_AuthorizationAccess: function () {
			var oModel = this.getOwnerComponent().getModel();
			var oAuthModel = this.getOwnerComponent().getModel("oAuthModel"),
				that = this;
			if (!oAuthModel.oData) {
				sap.ui.core.BusyIndicator.show();
				oModel.read("/UserAuthSet", {
					success: function (oData, response) {
						oAuthModel.setData(oData);
						var appModel = that.getModel("APP");

						var isMET = oData.results.some(function (item) {
							return (item.Met === "Y");
						});

						appModel.setProperty("/met", isMET);
						appModel.setProperty("/isMET", isMET);
						appModel.setProperty("/isITSupport", isMET);
						appModel.setProperty("/is3rdParty", isMET);

						sap.ui.core.BusyIndicator.hide();
					},
					error: function (oError) {
						sap.ui.core.BusyIndicator.hide();
					}
				});
			}
		},

		_domainData: function (oEvent) {
			var oModel = this.getOwnerComponent().getModel();
			var oEmailDomain = this.getOwnerComponent().getModel("oEmailDomain");

			sap.ui.core.BusyIndicator.show();
			oModel.read("/Email_DomainSet", {
				success: function (oData, response) {
					oEmailDomain.setData(oData);
					sap.ui.core.BusyIndicator.hide();
				},
				error: function (oError) {

					sap.ui.core.BusyIndicator.hide();
				}
			});

		},

		onRTVDetail: function (oEvent) {
			if (sap.ushell && sap.ushell.Container && sap.ushell.Container.getService) {
				window._metNavBack = 'X';
				jQuery.sap.require("jquery.sap.storage");
				var oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
				oStorage.put("rtvNavBack", window.location.href);
				this.RTVLabel = oEvent.getSource().getText();
				var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
				var action = "display&/object/" + this.getOwnerComponent().metGetSite() + "/" + this.RTVLabel + "";
				oCrossAppNavigator.toExternal({
					target: {
						semanticObject: "YViewRTVSem",
						action: action
					}
				});
			}
		}
	});
});