sap.ui.define([
		"com/hd/cageaudit/controller/BaseController"
	], function (BaseController) {
		"use strict";

		return BaseController.extend("YRTV_ONE_TILE.YRTV_ONE_TILE.controller.CageReport.NotFound", {

			/**
			 * Navigates to the worklist when the link is pressed
			 * @public
			 */
			onLinkPressed : function () {
				this.getRouter().navTo("worklist");
			}

		});

	}
);