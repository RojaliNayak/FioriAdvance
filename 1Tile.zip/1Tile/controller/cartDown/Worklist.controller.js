sap.ui.define([
	"YRTV_ONE_TILE/YRTV_ONE_TILE/controller/CageReport/BaseController",
	"sap/m/MessageToast",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"YRTV_ONE_TILE/YRTV_ONE_TILE/model/CageReport/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"YRTV_ONE_TILE/YRTV_ONE_TILE/pdfJSLib/pdfmake",
	"YRTV_ONE_TILE/YRTV_ONE_TILE/pdfJSLib/vfs_fonts",
	"sap/ui/model/Sorter",
	"sap/m/MessageBox",
	"sap/ui/core/util/Export",
	"sap/ui/core/util/ExportTypeCSV",
	'sap/ui/core/Fragment',
	'sap/m/Token',
	"sap/ui/core/format/DateFormat"
], function (BaseController, MessageToast, JSONModel, History, formatter, Filter, FilterOperator, pdfMake, Sorter, MessageBox, Export,
	ExportTypeCSV, Fragment, Token, DateFormat) {
	"use strict";

	return BaseController.extend("YRTV_ONE_TILE.YRTV_ONE_TILE.controller.CageReport.Worklist", {

		formatter: formatter,

		/* ================= ========================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit: function () {
			var oViewModel,
				iOriginalBusyDelay,
				oTable = this.byId("idCageTable");

			// Put down worklist table's original value for busy indicator delay,
			// so it can be restored later on. Busy handling on the table is
			// taken care of by the table itself.
			iOriginalBusyDelay = oTable.getBusyIndicatorDelay();
			// keeps the search state
			this._oTableSearchState = [];

			// Model used to manipulate control states
			oViewModel = new JSONModel({
				worklistTableTitle: this.getResourceBundle().getText("worklistTableTitle"),
				tableNoDataText: this.getResourceBundle().getText("tableNoDataText"),
				tableBusyDelay: 0
			});
			this.setModel(oViewModel, "worklistView");

			// Make sure, busy indication is showing immediately so there is no
			// break after the busy indication for loading the view's meta data is
			// ended (see promise 'oWhenMetadataIsLoaded' in AppController)
			oTable.attachEventOnce("updateFinished", function () {
				// Restore original busy indicator delay for worklist's table

			});

			this._AuthorizationAccess();
			if (!this._oDialog) {
				// create dialog via fragment factory
				this._oDialog = sap.ui.xmlfragment("YRTV_ONE_TILE.YRTV_ONE_TILE.view.CageReport.DetailCageReportSelection", this);
				// connect dialog to view (models, lifecycle)
				this.getView().addDependent(this._oDialog);
			}
			var oInput = sap.ui.getCore().byId("multiInput");
				oInput.setPlaceholder(this.getResourceBundle().getText("RTVStatus"));
			sap.ui.getCore().byId("idDateSelection2").setDateValue(new Date());
			this._oDialog.open();
		},

		onResetPress: function (evt) {
			this.onResetInpParameter();
		},
		onResetInpParameter: function (evt) {
			var store = sap.ui.getCore().byId("idSite");
			var vendor = sap.ui.getCore().byId("idVendors");
			var date1 = sap.ui.getCore().byId("idDateSelection1");
			var date2 = sap.ui.getCore().byId("idDateSelection2");
			var status = sap.ui.getCore().byId("multiInput");
			var rtvtype = sap.ui.getCore().byId("idRTVType");
			var label = sap.ui.getCore().byId("idLabel");
			var oList = sap.ui.getCore().byId("oStatusList");
			// date1.setDateValue(new Date());
			date1.setDateValue(new Date('00/00/0000'));
			date2.setDateValue(new Date());
			vendor.setValue("");
			label.setValue("");
			oList.removeSelections();
			// status.clearSelection();
			status.setValue('');
			rtvtype.setSelectedKey("");
			var oAuthModel = this.getOwnerComponent().getModel("oAuthModel");
			if (oAuthModel) {
				store.setValue(oAuthModel.getData().results[0].Store);
			}

		},
		onClosePress: function (evt) {
			// this.onResetInpParameter();
			this._oDialog.close();
		},
		handleDateChange1: function (oEvent) {
			// var sInputValue = oEvent.getSource().getValue();
			var oDate = sap.ui.getCore().byId("idDateSelection1");
			var oSearchBtn = sap.ui.getCore().byId("searchButton");
			var date1 = sap.ui.getCore().byId("idDateSelection1").getDateValue();
			var date2 = sap.ui.getCore().byId("idDateSelection2").getDateValue();
			var oMessage = this.getResourceBundle().getText("dateValidation");

			if (date1 && date2) {
				if (date1 > date2) {
					oDate.setValueState("Error");
					oSearchBtn.setEnabled(false);
					MessageToast.show(oMessage);
				} else {
					oDate.setValueState("None");
					oSearchBtn.setEnabled(true);
				}
			}

		},
		handleDateChange2: function (oEvent) {
			// var sInputValue = oEvent.getSource().getValue();
			var oDate = sap.ui.getCore().byId("idDateSelection2");
			var oSearchBtn = sap.ui.getCore().byId("searchButton");
			var date1 = sap.ui.getCore().byId("idDateSelection1").getDateValue();
			var date2 = sap.ui.getCore().byId("idDateSelection2").getDateValue();
			var oMessage = this.getResourceBundle().getText("dateValidation");
			if (date1 && date2) {
				if (date1 > date2) {
					oDate.setValueState("Error");
					oSearchBtn.setEnabled(false);
					MessageToast.show(oMessage);
				} else {
					oDate.setValueState("None");
					oSearchBtn.setEnabled(true);
				}
			}

		},

		handleValueHelp: function (oEvent) {
			if (!this._mDialog) {
				// create dialog via fragment factory
				this._mDialog = sap.ui.xmlfragment("YRTV_ONE_TILE.YRTV_ONE_TILE.view.CageReport.Dialog", this);
				// connect dialog to view (models, lifecycle)
				this.getView().addDependent(this._mDialog);
			}
			this._mDialog.open();
		},
		onCloseStatus: function (oEvent) {
			var oInput = sap.ui.getCore().byId("multiInput"),
				oList = sap.ui.getCore().byId("oStatusList"),
				oItems = oList.getSelectedItems();
			oInput.setValue('');
			for (var i = 0; i < oItems.length; i++) {
				if (i === 0) {
					oInput.setValue(oItems[i].getTitle() + "(" + oItems[i].getDescription() + ")" + ",");
				} else {
					var oValue = oInput.getValue();
					oInput.setValue(oValue + oItems[i].getTitle() + "(" + oItems[i].getDescription() + ")" + ",");
				}

			}

			this._mDialog.close();
		},

		onLabelLiveChange: function (evt) {
			var fld = evt.getSource(),
				value = evt.getParameters().value;
			if (value !== "") {
				if (parseInt(value, 10).toString().length > 17) {
					fld.setValueState(sap.ui.core.ValueState.Error);
					fld.setValue(value.slice(0, -1));
					MessageToast.show(this.getResourceBundle().getText("PleaseEnter17DigitLabelNumber"));
					return;
				} else if (parseInt(value, 10).toString().length === 17) {
					// articleModel.setProperty("Valid", true, bindingContext);
					fld.updateDomValue(value);
					fld.setValueState(sap.ui.core.ValueState.None);
					// this.onColorCodeUpdate(evt);
				} else if (parseInt(value, 10).toString().length < 17) {
					fld.updateDomValue(value);
					fld.setValueState(sap.ui.core.ValueState.None);
					// this.onColorCodeUpdate(evt);
				}
			}
		},

		onSearchReport: function (evt) {
			var store = sap.ui.getCore().byId("idSite");
			var oMessage = this.getResourceBundle().getText("storeValidation");
			if (store.getValue()) {

				this.getData();
				// this.onResetInpParameter();
				this._oDialog.close();

			} else {

				MessageToast.show(oMessage);
			}
		},

		onGetSelection: function (evt) {
			// this.onResetInpParameter();
			if (!this._oDialog) {
				// create dialog via fragment factory
				this._oDialog = sap.ui.xmlfragment("YRTV_ONE_TILE.YRTV_ONE_TILE.view.CageReport.DetailCageReportSelection", this);
				// connect dialog to view (models, lifecycle)
				this.getView().addDependent(this._oDialog);
			}
			var oInput = sap.ui.getCore().byId("multiInput");
				oInput.setPlaceholder(this.getResourceBundle().getText("RTVStatus"));
			this._oDialog.open();

		},
		foramatDate: function (oDate) {
			if (oDate) {
				return oDate;
			} else {
				oDate = "00000000";
			}
			return oDate;
		},
		getData: function () {

			var cageAuditModel = new JSONModel(),
				oTable = this.byId("idCageTable");
			this.setModel(cageAuditModel, "cageModel");
			var store = sap.ui.getCore().byId("idSite");
			var vendor = sap.ui.getCore().byId("idVendors");
			var date1 = sap.ui.getCore().byId("idDateSelection1").getValue();
			var date2 = sap.ui.getCore().byId("idDateSelection2").getValue();
			var status = sap.ui.getCore().byId("multiInput").getValue();
			var rtvtype = sap.ui.getCore().byId("idRTVType");
			var label = sap.ui.getCore().byId("idLabel");
			var oDate = this.foramatDate(date1) + "-" + this.foramatDate(date2);
			// var oStatusValue = status.getSelectedItems();
			//rawDataModel used for sorting 
			var rawDataModel = new JSONModel();
			this.setModel(rawDataModel, "rawDataModel");
			var aFilters = [];
			var that = this;
			aFilters.push(new Filter("Werks", sap.ui.model.FilterOperator.EQ, store.getValue()));
			aFilters.push(new Filter("RTV_type", sap.ui.model.FilterOperator.EQ, rtvtype.getSelectedKey()));
			aFilters.push(new Filter("Lifnr", sap.ui.model.FilterOperator.EQ, vendor.getValue()));
			aFilters.push(new Filter("LabelNum", sap.ui.model.FilterOperator.EQ, label.getValue()));
			aFilters.push(new Filter("Erdat", sap.ui.model.FilterOperator.EQ, oDate));
			var oStatusValue = status.split(',');
			for (var i = 0; i < oStatusValue.length; i++) {
				var oStatusSplit = oStatusValue[i].split('(');
				if(oStatusSplit[1]){
				aFilters.push(new Filter("Status", sap.ui.model.FilterOperator.EQ, oStatusSplit[1].slice(0,3)));
				}
			}
			// aFilters.push(new Filter("Status", sap.ui.model.FilterOperator.EQ, status.getSelectedKeys()));

			var oModel = this.getOwnerComponent().getModel();
			var sPath = "/CAGE_AUDITSet";
			oTable.setBusy(true);
			var Dept, subTotalQty = 0,
				subTotalCost = 0;
			var records = [];
			oModel.read(sPath, {
				filters: aFilters,
				success: function (oData) {
					var oMessage = that.getResourceBundle().getText("total");
					//Calculating subtotals - On initial load we get data sorted by Dept.
					if (oData.results.length > 0) {
						Dept = oData.results[0].Dept;
						for (var i = 0; i < oData.results.length; i++) {
							subTotalQty = subTotalQty + Number(oData.results[i].Menge);
							subTotalCost = subTotalCost + Number(oData.results[i].ExtCost);
							oData.results[i].setBackground = "No";
							if (oData.results[i].Werks === "") {
								records.push({
									Dept: oMessage,
									Meins: oData.results[i - 1].Meins,
									Menge: subTotalQty + "",
									ExtCost: oData.results[i].ExtCost,
									Werks: oData.results[i - 1].Werks,
									LabelNum: "",
									setBackground: "Yes"
								});
							} else {
								records.push(
									oData.results[i]
								);
							}
						}
					} else {
						cageAuditModel.setData({
							results: [],
							siteId: ""
						});
						oTable.setBusy(false);
					}
					//cageAuditModel used for binding UI controls.
					cageAuditModel.setData({
						results: records,
						siteId: records[0].Werks
					});

					//rawDataModel used for sorting.
					rawDataModel.setData({
						sortedByDept: records,
						rawData: oData.results
					});
					oTable.setBusy(false);
				},
				error: function (oError) {
					cageAuditModel.setData({
						results: [],
						siteId: ""
					});
					oTable.setBusy(false);
					var Error = JSON.parse(oError.responseText).error.message.value;
					MessageToast.show(Error);
				}
			});

		},
		_AuthorizationAccess: function () {
			var oModel = this.getOwnerComponent().getModel();
			var oAuthModel = this.getOwnerComponent().getModel("oAuthModel");
			var newBtn = this.byId("idNewBtn");

			sap.ui.core.BusyIndicator.show();
			oModel.read("/UserAuthSet", {
				success: function (oData, response) {
					oAuthModel.setData(oData);
					var store = sap.ui.getCore().byId("idSite");
					store.setValue(oAuthModel.getData().results[0].Store);
					sap.ui.core.BusyIndicator.hide();
				},
				error: function (oError) {
					sap.ui.core.BusyIndicator.hide();
				}
			});
		},

		onViewSettingsPress: function () {
			if (!this._sDialog) {
				this._sDialog = sap.ui.xmlfragment("YRTV_ONE_TILE.YRTV_ONE_TILE.view.CageReport.SettingsDialog", this);
				this.getView().addDependent(this._sDialog);
			}
			// toggle compact style
			jQuery.sap.syncStyleClass("sapUiSizeCompact", this.getView(), this._sDialog);
		
			this._sDialog.open();
		},

		handleConfirm: function (oEvent) {
			var that = this;
			var oView = this.getView();
			var mParams = oEvent.getParameters();
			var oTable = oView.byId("idCageTable");
			oTable.setBusy(true);

			var sPath = mParams.sortItem.getKey();
			var bDescending = mParams.sortDescending;

			var cageModel = oView.getModel("cageModel");
			var rawDataModel = oView.getModel("rawDataModel");
			var oMessage = this.getResourceBundle().getText("total");

			//Sorting
			var sortedRawData = rawDataModel.getData().rawData;
			sortedRawData.sort(function (a, b) {
				return that.sortBy(a, b, sPath, bDescending);
			});
			var subTotalQty = 0,
				subTotalCost = 0,
				records = [],
				total = [],
				len,
				subTotalObj;

			len = sortedRawData.length;
			if (bDescending) {
				total = sortedRawData[len - 1];
				sortedRawData = sortedRawData.slice(0, len - 1);
			} else {
				total = sortedRawData[0];
				sortedRawData = sortedRawData.slice(1, len);
			}

			var sorterParam = sortedRawData[0][sPath];
			for (var i = 0; i < sortedRawData.length; i++) {
				subTotalQty = subTotalQty + Number(sortedRawData[i].Menge);
				subTotalCost = subTotalCost + Number(sortedRawData[i].ExtCost);
				records.push(sortedRawData[i]);
			}
			records.push({
				Dept: oMessage,
				Meins: sortedRawData[0].Meins,
				Menge: subTotalQty + "",
				ExtCost: total.ExtCost,
				Werks: sortedRawData[0].Werks,
				LabelNum: "",
				setBackground: "Yes"
			});
			cageModel.setData({
				results: records,
				siteId: records[0].Werks
			});
			cageModel.checkUpdate(true);
			oTable.setBusy(false);

		},

		sortBy: function (a, b, sPath, reverse) {
			var result = (a[sPath] > b[sPath]) ? 1 : ((b[sPath] > a[sPath]) ? -1 : 0);
			var order = reverse ? -1 : 1;
			return result * order;
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */
		/**
		 * Event handler for navigating back.
		 * It there is a history entry or an previous app-to-app navigation we go one step back in the browser history
		 * If not, it will navigate to the shell home
		 * @public
		 */
		onNavBack: function () {

			window.history.go(-1);
			// var sPreviousHash = History.getInstance().getPreviousHash(),
			// 	oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");

			// if (sPreviousHash !== undefined || !oCrossAppNavigator.isInitialNavigation) {
			// 	history.go(-1);
			// } else {

			// 	oCrossAppNavigator.toExternal({
			// 		target: {
			// 			semanticObject: "#"
			// 		}
			// 	});
			// }
		},

		/**
		 * Event handler when the share in JAM button has been clicked
		 * @public
		 */
		/**
		 * Event handler for refresh event. Keeps filter, sort
		 * and group settings and refreshes the list binding.
		 * @public
		 */
		onRefresh: function () {
			var oTable = this.byId("idCageTable");
			oTable.getBinding("items").refresh();
		},

		/* =========================================================== */
		/* internal methods                                            */
		/* =========================================================== */

		/**
		 * Shows the selected item on the object page
		 * On phones a additional history entry is created
		 * @param {sap.m.ObjectListItem} oItem selected Item
		 * @private
		 */
		/**
		 * Internal helper method to apply both filter and search state together on the list binding
		 * @param {object} oTableSearchState an array of filters for the search
		 * @private
		 */

		onExportToPDF: function () {
			sap.ui.core.BusyIndicator.show();
			var oTable = this.byId("idCageTable");
			oTable.setBusy(true);
			var oTabdata = oTable.getModel("cageModel");
			var cageModelData = oTabdata.getData();
			var odata = cageModelData.results;
			if (odata.length > 0) {
				var oResourceBundle = this.getResourceBundle();
				var docDefinition = {
					pageSize: 'A4',
					pageOrientation: 'landscape',
					header: [{
						columns: [{
							text: oResourceBundle.getText("Site") + ':' + cageModelData.siteId,
							alignment: 'left',
							width: '40%'
						}, {
							text: oResourceBundle.getText("worklistViewTitle"),
							fontSize: 14,
							bold: true
						}],
						style: 'headerMargins'
					}],
					content: [{
						table: {
							headerRows: 1,
							body: [
								[{
									text: oResourceBundle.getText("Dept"),
									style: 'tableHeader'
								}, {
									text: oResourceBundle.getText("ChargeVendor"),
									style: 'tableHeader'
								}, {
									text: oResourceBundle.getText("Article"),
									style: 'tableHeader'
								}, {
									text: oResourceBundle.getText("ArticleDescription"),
									style: 'tableHeader'
								}, {
									text: oResourceBundle.getText("PartNumber"),
									style: 'tableHeader'
								}, {
									text: oResourceBundle.getText("RTVLabelNumber"),
									style: 'tableHeader'
								}, {
									text: oResourceBundle.getText("DateCreated"),
									style: 'tableHeader'
								}, {
									text: oResourceBundle.getText("Qty"),
									style: 'tableHeader'
								}, {
									text: oResourceBundle.getText("Cost"),
									style: 'tableHeader'
								}, {
									text: oResourceBundle.getText("TotalCost"),
									style: 'tableHeader'
								}, {
									text: oResourceBundle.getText("User"),
									style: 'tableHeader'
								}, {
									text: oResourceBundle.getText("RTVOverallStatus"),
									style: 'tableHeader'
								}]
							]
						}
					}],
					footer: function (currentPage, pageCount) {
						return {
							text: '',
							columns: [{
								text: '',
								width: '20%',
								alignment: 'center'
							}, {
								text: oResourceBundle.getText('HomeDepotCanada'),
								width: '60%',
								alignment: 'center'
							}, {
								text: 'Page ' + currentPage.toString() + ' of ' + pageCount,
								width: '20%',
								alignment: 'center'
							}], //Feb 16, 2017 11:38:37 AM
							style: 'footerMargins'
						};
					},
					styles: {
						headerMargins: {
							margin: [40, 20, 0, 0]
						},
						tableHeader: {
							fontSize: 7,
							bold: true,
							fillColor: '#eeeeee'
						},
						footerMargins: {
							margin: [30, 10, 20, 0]
						}
					}
				};
				var str1 = "";
				for (var i = 0; i < odata.length; i++) {

					var count = 0;
					str1 = [{
						text: odata[i].Dept ? odata[i].Dept : "",
						fontSize: 6
					}, {
						text: odata[i].VendName ? odata[i].VendName : "",
						fontSize: 6
					}, {
						text: odata[i].Matnr ? odata[i].Matnr : "",
						fontSize: 6
					}, {
						text: odata[i].Maktx ? odata[i].Maktx : "",
						fontSize: 6
					}, {
						text: odata[i].Idnlf ? odata[i].Idnlf : "",
						fontSize: 6
					}, {
						text: odata[i].LabelNum ? odata[i].LabelNum : "",
						fontSize: 6
					}, {
						text: odata[i].Erdat ? this.getFormattedDate(odata[i].Erdat) : "",
						fontSize: 6
					}, {
						text: odata[i].Menge ? formatter.truncateQty(odata[i].Menge, odata[i].Meins) : "",
						fontSize: 6
					}, {
						text: odata[i].ItemCost ? formatter.truncateValue(odata[i].ItemCost) : "",
						fontSize: 6
					}, {
						text: odata[i].ExtCost ? formatter.truncateValue(odata[i].ExtCost) : "",
						fontSize: 6
					}, {
						text: odata[i].Ernam ? odata[i].Ernam : "",
						fontSize: 6
					}, {
						text: odata[i].StatusName ? odata[i].StatusName : "",
						fontSize: 6
					}];

					for (var k = 0; k < str1.length; k++) {
						if (str1[k].text === "") {
							count++;
						}
					}
					if (count > 6) {
						for (var j = 0; j < str1.length; j++) {
							str1[j].fillColor = '#b4b4b4';
							str1[j].bold = true;
						}
					}
					docDefinition.content[0].table.body.push(str1);
					str1 = "";
				}
				window.pdfMake.createPdf(docDefinition).download(oResourceBundle.getText("CageAuditReport") + ".pdf");
				sap.ui.core.BusyIndicator.hide();
				oTable.setBusy(false);
			} else {
				sap.ui.core.BusyIndicator.hide();
				oTable.setBusy(false);
				MessageToast.show(this.getResourceBundle().getText("NoData"));

			}
		},
		
		onExportToExcel: function () {
			jQuery.sap.require("sap.ui.export.Spreadsheet");
			sap.ui.core.BusyIndicator.show();
			var oTable = this.byId("idCageTable");
			oTable.setBusy(true);
			var oTabdata = oTable.getModel("cageModel");
			var cageModelData = oTabdata.getData();
			var odata = cageModelData.results;
			if (odata.length > 0) {
				var oResourceBundle = this.getResourceBundle();

			 var aColumns = [];
			  aColumns.push({
			  	label: oResourceBundle.getText("Dept"),
			  	property: "Dept"
			  });
			  aColumns.push({
			  	label: oResourceBundle.getText("ChargeVendor"),
			  	property: "VendName"
			  });
			  aColumns.push({
			    label: oResourceBundle.getText("Article"),
			    property: "Matnr",
			  });
			  aColumns.push({
			    label: oResourceBundle.getText("ArticleDescription"),
			    property: "Maktx",
			  });
			  aColumns.push({
			    label: oResourceBundle.getText("PartNumber"),
			    property: "Idnlf",
			  });
			  aColumns.push({
			    label: oResourceBundle.getText("RTVLabelNumber"),
			    property: "LabelNum",
			  });
			  aColumns.push({
			    label: oResourceBundle.getText("DateCreated"),
			    inputFormat: 'yyyymmdd',
			    format: "mm/dd/yyyy",
			    property: "Erdat",
			    type:	  "Date",
			  });
			  aColumns.push({
			    label: oResourceBundle.getText("Qty"),
			    property: "Menge",
			    scale: 0,
			    type: "Number",
			  });
			  aColumns.push({
			    label: oResourceBundle.getText("Uom"),
			    property: "Meins",
			  });
			  aColumns.push({
			    label: oResourceBundle.getText("Cost"),
			    property: "ItemCost",
			    scale: 2,
			    type: "Number"
			  });
			  aColumns[9].unit = '$';
			  aColumns.push({
			    label: oResourceBundle.getText("TotalCost"),
			    property: "ExtCost",
			    scale: 2,
			    type: "Number"
			  });
			  aColumns[10].unit = '$';
			  aColumns.push({
			    label: oResourceBundle.getText("User"),
			    property: "Ernam",
			  });
			  aColumns.push({
			    label: oResourceBundle.getText("RTVOverallStatus"),
			    property: "StatusName",
			  });
			  		  
			
			  var mSettings = {
			    workbook: {
			      columns: aColumns,
			      context: {
			        application: 'Cage Audit Report',
			        title: oResourceBundle.getText("worklistViewTitle") + ", " + oResourceBundle.getText("Site") + ':' + cageModelData.siteId,
			        modifiedBy: '',
			      },
			      hierarchyLevel: ''
			    },
			    dataSource: odata,
			    fileName: oResourceBundle.getText("worklistViewTitle") + ", " + oResourceBundle.getText("Site") + ':' + cageModelData.siteId
			  };
			  var oSpreadsheet = new sap.ui.export.Spreadsheet(mSettings);
			  oSpreadsheet.build();
			  oTable.setBusy(false);
			  sap.ui.core.BusyIndicator.hide();
			}else {
				sap.ui.core.BusyIndicator.hide();
				oTable.setBusy(false);
				MessageToast.show(this.getResourceBundle().getText("NoData"));
			}
		},

		getFormattedDate: function (date) {
			if (date) {
				if (date === "00000000") {
					return "";
				} else if (date !== "00000000") {
					var oLength = date.length;
					var oDate;
					if (oLength === 10) {
						oDate = date.slice(5, 7) + "/" + date.slice(8, 10) + "/" + date.slice(0, 4);
					}
					if (!oLength) {
						return date;
					} else {
						oDate = date.slice(4, 6) + "/" + date.slice(6, 8) + "/" + date.slice(0, 4);
					}
					return oDate;
				} else {
					return date;
				}
			}
		}
	});
});