/*global history */
sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"sap/ui/core/format/DateFormat"
], function(Controller, History, DateFormat) {
	"use strict";

	return Controller.extend("com.hd.rtvview.controller.BaseController", {
		
		DateFormat: DateFormat.getDateInstance({
			pattern: "MM/dd/yyyy"
		}),

		Date2NumFormat: DateFormat.getDateInstance({
			pattern: "yyyyMMdd"
		}),
		
		onInit: function() {
			if ( this.getView().sViewName === "com.hd.rtvview.view.NotFound" )
			{
				this.getView().addEventDelegate({
					onBeforeFirstShow: function() {
						this.getRouter().getTargets().display("master");
					}.bind(this)
				});
							
			}
		},
		
		/**
		 * Convenience method for accessing the router in every controller of the application.
		 * @public
		 * @returns {sap.ui.core.routing.Router} the router for this component
		 */
		getRouter: function() {
			return this.getOwnerComponent().getRouter();
		},

		/**
		 * Convenience method for getting the view model by name in every controller of the application.
		 * @public
		 * @param {string} sName the model name
		 * @returns {sap.ui.model.Model} the model instance
		 */
		getModel: function(sName) {
			return this.getView().getModel(sName);
		},

		/**
		 * Convenience method for setting the view model in every controller of the application.
		 * @public
		 * @param {sap.ui.model.Model} oModel the model instance
		 * @param {string} sName the model name
		 * @returns {sap.ui.mvc.View} the view instance
		 */
		setModel: function(oModel, sName) {
			return this.getView().setModel(oModel, sName);
		},

		/**
		 * Convenience method for getting the resource bundle.
		 * @public
		 * @returns {sap.ui.model.resource.ResourceModel} the resourceModel of the component
		 */
		getResourceBundle: function() {
			return this.getOwnerComponent().getModel("i18n").getResourceBundle();
		},
		
		onNavBackBase: function() {
			this.getOwnerComponent().list.setSelectedItem(this.getOwnerComponent().list.getSelectedItem(), false);
			this.getRouter().getTargets().display("master");
			this.getOwnerComponent().listBack = "X";
		},
		
		serviceError: function(oError) {
			var that = this;
			sap.m.MessageBox.show(
				JSON.parse(oError.responseText).error.message.value, {
					icon: sap.m.MessageBox.Icon.ERROR,
					title: that.getResourceBundle().getText("Error"),
					actions: [sap.m.MessageBox.Action.OK],
					onClose: function(oAction) {
						var message_class = JSON.parse(oError.responseText).error.code.substring(0, 11);
						if (message_class === "YDRTV_ABORT") {
									if (sap.ushell && sap.ushell.Container && sap.ushell.Container.getService) {
										var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
										oCrossAppNavigator.toExternal({
											target: {
												semanticObject: "#"
											}
										});
									}
						} else {
						//if(JSON.parse(oError.responseText).error.code === "Y_DSC_RTV/356") {
							that.getRouter().navTo("object",
							that.getModel("screen").getProperty("/detailPath"),
							true);
						/*} else {
							var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
							oCrossAppNavigator.toExternal({
								target: {
									semanticObject: "#"
								}
							});
						}*/
						}
					}
			});
		},
		
		onVKeypadHide: function() {
				if(window.plugin && window.plugin.firstphone) {
					window.plugin.firstphone.launcher.hideKeyboard();	
					jQuery.sap.delayedCall(0,this,function(){ 
						window.plugin.firstphone.launcher.hideKeyboard();
					});
				}
			}

	});

});