/*global history */
sap.ui.define([
	"YRTV_ONE_TILE/YRTV_ONE_TILE/controller/Buyback/BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/m/GroupHeaderListItem",
	"sap/ui/Device",
	"YRTV_ONE_TILE/YRTV_ONE_TILE/model/Buyback/formatter",
	"sap/ui/core/format/DateFormat"
], function (BaseController, JSONModel, History, Filter, FilterOperator, GroupHeaderListItem, Device, formatter, DateFormat) {
	"use strict";
	var __controller;
	return BaseController.extend("YRTV_ONE_TILE.YRTV_ONE_TILE.controller.Buyback.Master", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the master list controller is instantiated. It sets up the event handling for the master/detail communication and other lifecycle tasks.
		 * @public
		 */
		onInit: function () {
			this.getOwnerComponent().buybackComp();
			__controller = this;
			// Control state model
			var oList = this.byId("list"),
				oViewModel = this._createViewModel(),
				oAuthModel = this.getOwnerComponent().getModel("oAuthModel"),
				// Put down master list's original value for busy indicator delay,
				// so it can be restored later on. Busy handling on the master list is
				// taken care of by the master list itself.
				iOriginalBusyDelay = oList.getBusyIndicatorDelay();

			this._oList = oList;
			// keeps the filter and search state
			this._oListFilterState = {
				aFilter: [],
				aSearch: []
			};

			this.setModel(oViewModel, "masterView");
			// Make sure, busy indication is showing immediately so there is no
			// break after the busy indication for loading the view's meta data is
			// ended (see promise 'oWhenMetadataIsLoaded' in AppController)
			oList.attachEventOnce("updateFinished", function () {
				// Restore original busy indicator delay for the list
				oViewModel.setProperty("/delay", iOriginalBusyDelay);
				// __controller.getOwnerComponent().masterListLoaded.resolve();
			});

			this.getView().addEventDelegate({
				onBeforeFirstShow: function () {
					this.getOwnerComponent().oListSelector.setBoundMasterList(oList);
				}.bind(this)
			});

			sap.ui.getCore().getEventBus().subscribe("rtv.buyback", "RefreshMasterList", function () {
				__controller.onRefresh();
			}, this);

			this.getRouter().attachRouteMatched(this._onMasterMatched, this);
			this.getRouter().attachBypassed(this.onBypassed, this);
		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */
		_onMasterMatched: function (oEvent) {
			var parameters = oEvent.getParameters();
			// var oSearch = this.getView().byId("searchField");
			// oSearch.focus();
			if (parameters.name === "object") {
				__controller.sEbeln = parameters.arguments.EBELN;
				if (__controller.sEbeln) {
					$.when(__controller.getOwnerComponent().masterListLoaded).done(function () {
						var oList = __controller.byId("list"),
							items = oList.getItems();

						if (!$.isArray(items) || items.length == 0) {
							oList.attachEventOnce("updateFinished", __controller.syncSelection.bind(this));
						} else {
							__controller.syncSelection();
						}
					}.bind(__controller));
				}
			}

		},

		syncSelection: function () {
			var oList = this.byId("list"),
				items = oList.getItems(),
				poNum = __controller.sEbeln;

			if (items) {
				var __item__;

				items.forEach(function (item) {
					if (item) {
						var __object__ = item.getBindingContext("buybackMasterModel").getObject();
						if (__object__.EBELN) {
							if (poNum === __object__.EBELN) {
								if (!__item__) {
									__item__ = item;
								}
							}
						}
					}
				});

				if (__item__) {
					if (__item__ !== oList.getSelectedItem()) {
						oList.setSelectedItem(__item__, true);
						__controller.getOwnerComponent().selectedItem = __item__;
						// __controller.byId("MasterPage").scrollToElement(__item__, 500);
					}
				} else {
					oList.removeSelections();
				}
			}
		},
		/**
		 * After list data is available, this handler method updates the
		 * master list counter and hides the pull to refresh control, if
		 * necessary.
		 * @param {sap.ui.base.Event} oEvent the update finished event
		 * @public
		 */
		onUpdateFinished: function (oEvent) {
			// update the master list object counter after new data is loaded
			this._updateListItemCount(oEvent.getParameter("total"));
			// hide pull to refresh if necessary
			this.byId("pullToRefresh").hide();
			$.when(__controller.getOwnerComponent().masterListLoaded).done(function () {
				__controller._oList.setBusy(false);
			});
			// Scan auto focus and search is commneted for now
			// need to impliment article/upc search then un comment this function
			// var oSearch = this.getView().byId("searchField"),
			// 	oSId = oSearch.getId();
			// this.onScanMasterField(oSId);

		},

		onUpdateStarted: function (oEvent) {
			oEvent.getSource().setBusyIndicatorDelay(0);
			oEvent.getSource().setBusy(true);

		},

		/**
		 * Event handler for the master search field. Applies current
		 * filter value and triggers a new search. If the search field's
		 * 'refresh' button has been pressed, no new search is triggered
		 * and the list binding is refresh instead.
		 * @param {sap.ui.base.Event} oEvent the search event
		 * @public
		 */
		onSearch: function (oEvent) {
			if (oEvent.getParameters().refreshButtonPressed) {
				// Search field's 'refresh' button has been pressed.
				// This is visible if you select any master list item.
				// In this case no new search is triggered, we only
				// refresh the list binding.
				this.onRefresh();
				return;
			}

			var sQuery = oEvent.getParameter("query"),
				oQuery = oEvent.getSource().getValue();
			this._oList.bindItems("buybackMasterModel>/ShowList", this.getView().byId("poListItem"));
			if (sQuery || oQuery) {
				//if(!isNaN(sQuery)){
				if (!sQuery) {
					sQuery = oQuery;
				}
				this._search(sQuery, "EAN11");
				//}
			} else {
				this.prepareShowList();
			}

		},

		/**
		 * Event handler for refresh event. Keeps filter, sort
		 * and group settings and refreshes the list binding.
		 * @public
		 */
		onRefresh: function () {
			this.getOwnerComponent().loadMasterList();
			//this._oList.getBinding("items").refresh();
		},
		/**
		 * Event handler for the list selection event
		 * @param {sap.ui.base.Event} oEvent the list selectionChange event
		 * @public
		 */
		onSelectionChange: function (oEvent) {
			// get the list item, either from the listItem parameter or from the event's source itself (will depend on the device-dependent mode).
			// this._showDetail(oEvent.getParameter("listItem") || oEvent.getSource());
			this._AuthorizationAccess(oEvent.getParameter("listItem") || oEvent.getSource());
		},

		/**
		 * Event handler for the bypassed event, which is fired when no routing pattern matched.
		 * If there was an object selected in the master list, that selection is removed.
		 * @public
		 */
		onBypassed: function () {
			this._oList.removeSelections(true);
		},

		/**
		 * Event handler for navigating back.
		 * It there is a history entry or an previous app-to-app navigation we go one step back in the browser history
		 * If not, it will navigate to the shell home
		 * @public
		 */
		onNavHome: function () {
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("home", true);
		},

		/* =========================================================== */
		/* begin: internal methods                                     */
		/* =========================================================== */

		_createViewModel: function () {
			return new JSONModel({
				delay: 0,
				title: this.getResourceBundle().getText("masterTitleCount", [0]),
				noDataText: this.getResourceBundle().getText("masterListNoDataText")
					// sortBy: "YYDELDAT",
					// groupBy: "None"
			});
		},

		/**
		 * If the master route was hit (empty hash) we have to set
		 * the hash to to the first item in the list as soon as the
		 * listLoading is done and the first item in the list is known
		 * @private
		 */

		DateFormat: DateFormat.getDateInstance({
			pattern: "MM/dd/yyyy"
		}),

		formatDate: function (value) {
			if (!value) {
				return "";
			} else {
				var oLength = value.length;
				var oDate;
				if (oLength === 10) {
					oDate = value.slice(5, 7) + "/" + value.slice(8, 10) + "/" + value.slice(0, 4);
				} else {
					oDate = value.slice(4, 6) + "/" + value.slice(6, 8) + "/" + value.slice(0, 4);
				}
				return oDate;
				// return this.DateFormat.format(new Date(value.getTime() + new Date().getTimezoneOffset() * 60000));
				// return value;
			}
		},

		dueDateStatus: function (dueDate) {
			var currentDate = new Date();
			var futureDate = currentDate.setTime(currentDate.getTime() + (7 * 24 * 60 * 60 * 1000));
			var dueDateTime = Date.parse(dueDate);
			if (dueDateTime >= futureDate) {
				return "None";
			} else {
				return "Error";
			}
		},

		/**
		 * Shows the selected item on the detail page
		 * On phones a additional history entry is created
		 * @param {sap.m.ObjectListItem} oItem selected Item
		 * @private
		 */
		_showDetail: function (oItem) {
			this.getOwnerComponent().selectedItem = oItem;
			var bReplace = !Device.system.phone;
			var oContext = oItem.getBindingContext("buybackMasterModel");
			//var ABELN = "DF33";
			var ABELN = oContext.getProperty("ABELN");
			this.getRouter().navTo("object", {
				ABELN: ABELN,
				EBELN: oContext.getProperty("EBELN"),
				WERKS: oContext.getProperty("WERKS")
			}, bReplace);
		},

		/**
		 * Sets the item count on the master list header
		 * @param {integer} iTotalItems the total number of items in the list
		 * @private
		 */
		_updateListItemCount: function (iTotalItems) {
			var sTitle;
			// only update the counter if the length is final
			if (this._oList.getBinding("items").isLengthFinal()) {
				sTitle = this.getResourceBundle().getText("masterTitleCount", [iTotalItems]);
				this.getModel("masterView").setProperty("/title", sTitle);
			}
		},

		/**
		 * Internal helper method to apply both filter and search state together on the list binding
		 * @private
		 */
		_search: function (query, queryParam) {
			var oBuybackModel = this.getModel("buybackMasterModel");
			var aMainList = oBuybackModel.getData().MainList;
			var aShowList = [];
			var regexNum = /^[0-9]*$/;
			var sArticleNum = "000000000000000000".substring(0, (18 - query.length)) + query;
			var sPoNum = "0000000000".substring(0, (10 - query.length)) + query;
			//var sVenNum = "0000000000".substring(0, (10 - query.length)) + query;
			aMainList.forEach(function (mainListItem) {
				if (regexNum.test(query)) {
					if ((mainListItem.EAN11_LIST + ",").indexOf("," + query + ",") !== -1) {
						/*if(!aShowList.some(function(listItem){ return listItem.EBELN === mainListItem.EBELN;})) {
							if(aShowList.length > 0) aShowList.concat(aShowList, mainListItem);
							else*/
						aShowList.push(mainListItem);
						//}
					} else if ((mainListItem.ART_LIST + ",").indexOf("," + sArticleNum + ",") !== -1) {
						/*if(!aShowList.some(function(listItem){ return listItem.EBELN === mainListItem.EBELN;})) {
							if(aShowList.length > 0) aShowList.concat(aShowList, mainListItem);
							else*/
						aShowList.push(mainListItem);
						//}
					} else if (mainListItem.EBELN === sPoNum) {
						/*if(!aShowList.some(function(listItem){ return listItem.EBELN === mainListItem.EBELN;})) {
							if(aShowList.length > 0) aShowList.concat(aShowList, mainListItem);
							else*/
						aShowList.push(mainListItem);
						//}
					}
				} else {
					if (((mainListItem.NAME1).toLowerCase()).indexOf(query.toLowerCase()) !== -1) {
						/*if(!aShowList.some(function(listItem){ return listItem.EBELN === mainListItem.EBELN;})) {
							if(aShowList.length > 0) aShowList.concat(aShowList, mainListItem);
							else*/
						aShowList.push(mainListItem);
						//}
					}
				}
			});
			oBuybackModel.setProperty("/ShowList", aShowList);
			/*if(aShowList.length === 0){
				if(queryParam === "EAN11"){
					this._search(query, "MATNR");
				}else if(queryParam === "MATNR"){
					this._search(query, "EBELN");
				}else{
					oBuybackModel.setProperty("/ShowList", aShowList);
				}
			}else{
				oBuybackModel.setProperty("/ShowList", aShowList);
			}*/
		},
		_AuthorizationAccess: function (oItem) {
			var oModel = this.getModel();
			var oAuthModel = this.getOwnerComponent().getModel("oAuthModel");
			var that = this;
			sap.ui.core.BusyIndicator.show();
			if (!oAuthModel.getData()) {
				oModel.read("/UserAuthSet", {
					success: function (oData, response) {
						oAuthModel.setData(oData.results[0]);
						sap.ui.core.BusyIndicator.hide();
						if (oItem) {
							that._showDetail(oItem);
						}
					},
					error: function (oError) {
						that.createRTVBtn.setVisible(false);
						sap.ui.core.BusyIndicator.hide();
						if (oItem) {
							that._showDetail(oItem);
						}
					}
				});
			} else {
				if (oItem) {
					that._showDetail(oItem);
				}
			}
		},

		prepareShowList: function () {
			var oBuybackMasterModel = this.getModel("buybackMasterModel");
			var MainList = oBuybackMasterModel.getData().MainList;
			var ShowList = [];
			MainList.forEach(function (MainListItem) {
				if (!ShowList.some(function (showListItem) {
						return showListItem.EBELN === MainListItem.EBELN;
					})) {
					ShowList.push(MainListItem);
				}
			});
			oBuybackMasterModel.setProperty("/ShowList", ShowList);
		},

		onMenuButtonPress: function () {
			var oRouter = this.getOwnerComponent().getRouter();
			oRouter.navTo("Menu", {});
		},

	});

});