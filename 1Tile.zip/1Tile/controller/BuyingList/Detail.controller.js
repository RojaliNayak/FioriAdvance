/*global location */
sap.ui.define([
	"YRTV_ONE_TILE/YRTV_ONE_TILE/controller/Buyback/BaseController",
	"sap/ui/model/json/JSONModel",
	"YRTV_ONE_TILE/YRTV_ONE_TILE/model/Buyback/formatter",
	"sap/ui/model/Filter",
	"sap/ui/core/format/DateFormat",
	"sap/m/MessageBox",
	"sap/m/MessageToast"
], function (BaseController, JSONModel, formatter, Filter, DateFormat, MessageBox, MessageToast) {
	"use strict";
	var __controller;
	var oMessagePopover;
	return BaseController.extend("YRTV_ONE_TILE.YRTV_ONE_TILE.controller.Buyback.Detail", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		onInit: function () {
			__controller = this;

			// Model used to manipulate control states. The chosen values make sure,
			// detail page is busy indication immediately so there is no break in
			// between the busy indication for loading the view's meta data
			var oViewModel = new JSONModel({
				busy: false,
				delay: 0
			});

			this.setModel(new JSONModel({
				PendingArticles: [],
				ScannedArticles: [],
				CompleteArticles: [],
				EMAIL_TO: "",
				EMAIL_CC: "",
				EMAIL_TEXT: "",
				EnableEmailSend: false,
				ValidToEmailAdd: true
			}), "buybackDetailsModel");

			this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);

			this.setModel(oViewModel, "detailView");

			// this.enableSaveBtn();
			this.getModel("buybackDetailsModel").checkUpdate(true);
			this.getOwnerComponent().getModel().metadataLoaded().then(this._onMetadataLoaded.bind(this));

			this.initMessagePopover();
		},

		// enableSaveBtn: function(){
		// 	var buybackModel = this.getModel("buybackDetailsModel");
		// 	var buybackModelData = buybackModel.getData();
		// 	if(!Object.getOwnPropertyDescriptor(buybackModelData, "enableSaveBtn")){
		// 		Object.defineProperty(buybackModelData, "enableSaveBtn", {
		// 			set: function(){},
		// 			get: function(){
		// 				if(this.ScannedArticles.length !== 0){
		// 					return this.ScannedArticles.some(function(element, array, idx){
		// 						return Number(element.SAVED_QTY) !== 0;
		// 					});
		// 				}
		// 				return false;
		// 			}
		// 		});
		// 	}
		// },

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/* =========================================================== */
		/* begin: internal methods                                     */
		/* =========================================================== */

		/**
		 * Binds the view to the object path and expands the aggregated line items.
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
		 * @private
		 */
		_onObjectMatched: function (oEvent) {
			
			var detailActiveTab = jQuery.sap.storage(jQuery.sap.storage.Type.session).get("buybackStorageTab");
			this.getView().getAggregation('content')[0].setEnableScrolling(true);
			var oArguments = oEvent.getParameter("arguments");
			__controller.sEbeln = oArguments.EBELN;
			var sAbeln = oArguments.ABELN;
			__controller.StorId = oArguments.WERKS;
			var detailsFilters, contactFilters;

			this._showButton(false);
			this.byId('messagePopoverBtn').setVisible(false);
			this.getModel('buybackDetailsModel').setProperty('/messagePopoverBtnVisible', false);
			if (detailActiveTab == "complete") {
				this.getView().byId("iconTabBar").setSelectedKey("complete");
				
				var oFilters = [new Filter("EBELN", "EQ", __controller.sEbeln),
					new Filter("WERKS", "EQ", __controller.StorId)
				];

				$.when(this.getOwnerComponent().masterListLoaded).done(function () {
					var sObjectPath = "PO_DETAILSet";
					detailsFilters = [new Filter("EBELN", "EQ", __controller.sEbeln)];
					__controller._bindView("/" + sObjectPath, detailsFilters);

					contactFilters = [new Filter("EBELN", "EQ", __controller.sEbeln),
						new Filter("ABELN", "EQ", sAbeln),
						new Filter("WERKS", "EQ", __controller.StorId)
					];
					//getting Details and Merchant tab details
					__controller._bindTabs("/CONTACTSet", contactFilters);
				}.bind(__controller));

				// this.onRefreshDetail(__controller.sEbeln);
				var that = this;
				that.getModel('buybackDetailsModel').setProperty("/busy", true);
				this.getModel().read("/BBCompleteSet", {
					filters: oFilters,
					success: function (odata) {
						if (odata.results && odata.results[0]) {
							var aCompleteArticles = [];
							odata.results.forEach(function (item) {
								item.MATNR = __controller.formatter.removeLeadingZeroes(item.MATNR);
								aCompleteArticles.push(item);
							});
							that.getModel('buybackDetailsModel').setProperty("/CompleteArticles", aCompleteArticles);
						}
						that.getModel('buybackDetailsModel').setProperty("/busy", false);
					},
					error: function (oError) {}
				});
			} else {
				// this.getView().byId("iconTabBar").setSelectedKey("details");

				// this.getModel().metadataLoaded().then( function() {

				if (detailActiveTab == "articles") {
					this.getView().byId("iconTabBar").setSelectedKey("articles");
					
					this._AuthorizationVerifyAccess();
				}
				$.when(this.getOwnerComponent().masterListLoaded).done(function () {
					var sObjectPath = "PO_DETAILSet";
					detailsFilters = [new Filter("EBELN", "EQ", __controller.sEbeln)];
					__controller._bindView("/" + sObjectPath, detailsFilters);

					contactFilters = [new Filter("EBELN", "EQ", __controller.sEbeln),
						new Filter("ABELN", "EQ", sAbeln),
						new Filter("WERKS", "EQ", __controller.StorId)
					];
					//getting Details and Merchant tab details
					__controller._bindTabs("/CONTACTSet", contactFilters);
				}.bind(__controller));
			}
		},

		/**
		 * Binds the view to the object path. Makes sure that detail view displays
		 * a busy indicator while data for the corresponding element binding is loaded.
		 * @function
		 * @param {string} sObjectPath path to the object to be bound to the view.
		 * @private
		 */
		onRefreshDetail: function (EBELN) {
			var detailsFilters = [new Filter("EBELN", "EQ", EBELN)];
			this._bindView("/PO_DETAILSet", detailsFilters);
		},

		_bindView: function (sObjectPath, oFilters) {
			// Set busy indicator during view binding
			var oViewModel = this.getModel("detailView");

			// If the view was not bound yet its not busy, only if the binding requests data it is set to busy again
			oViewModel.setProperty("/busy", true);
			var oModel = this.getModel();
			var selectedItem = this.getOwnerComponent().selectedItem;
			this.selectedItem = selectedItem;
			var buybackDetailsModel = this.getModel("buybackDetailsModel");
			buybackDetailsModel.setProperty("/ScannedArticles", []);
			buybackDetailsModel.setProperty("/PendingArticles", []);
			if (selectedItem === null || selectedItem === undefined) {
				this.getRouter().navTo("masterBuyback", {});
				return;
			}
			var selectedBuybackObject = selectedItem.getBindingContext("buybackMasterModel").getObject();
			__controller.__addAttrInBuybackModel(selectedBuybackObject);
			oModel.read(sObjectPath, {
				filters: oFilters,
				urlParameters: {
					"$expand": "ToBay,ToOHMBay,PO_DETAIL_ARTICLE_UPCSET"
				},
				success: function (odata) {
					if (odata.results && odata.results[0]) {
						// buybackDetailsModel.setProperty("/CompleteArticles", $.grep(odata.results, function (item, i) {
						// 	item.MATNR = __controller.formatter.removeLeadingZeroes(item.MATNR);
						// 	item.ON_HAND_QTY = parseFloat(item.ON_HAND_QTY);
						// 	item.SAVED_QTY = parseFloat(item.SAVED_QTY);
						// 	return (item.LABEL_NUM !== "");
						// }));
						buybackDetailsModel.setProperty("/PendingArticles", $.grep(odata.results, function (item, i) {
							item.MATNR = __controller.formatter.removeLeadingZeroes(item.MATNR);
							item.ON_HAND_QTY = parseFloat(item.ON_HAND_QTY);
							item.SAVED_QTY = parseFloat(item.SAVED_QTY);
							return (item.LABEL_NUM === "");
						}));
						var pendingList = buybackDetailsModel.getData().PendingArticles;
						var scanList = buybackDetailsModel.getData().ScannedArticles;
						// pendingList.some(function (item, i) {
						// 	if (item && item.SAVED_QTY !== 0) {
						// 		scanList = scanList.concat(pendingList.splice(i, 1));
						// 	}
						// });
						var pendingIems = [],
							scannedItems = [];
						pendingList.forEach(function (item) {
							if (item && item.SAVED_QTY !== 0)
								scannedItems.push(item);
							else
								pendingIems.push(item);

						});
						buybackDetailsModel.setProperty("/ScannedArticles", scannedItems);
						buybackDetailsModel.setProperty("/PendingArticles", pendingIems);
						__controller.__addAttrInBuybackModel(odata.results[0]);
						__controller.__addAttrInBuybackModel(selectedBuybackObject);
					}
					oViewModel.setProperty("/busy", false);
				},
				error: function (oError) {
					if (oError.responseText && JSON.parse(oError.responseText).error.message) {
						MessageBox.show(
							JSON.parse(oError.responseText).error.message.value, {
								icon: sap.m.MessageBox.Icon.ERROR,
								title: __controller.getResourceBundle().getText("error"),
								actions: [sap.m.MessageBox.Action.OK]
							});
					} else {
						return;
					}
					oViewModel.setProperty("/busy", false);
				}
			});
		},

		_bindTabs: function (sObjectPath, sFilter) {
			var oModel = this.getModel();
			oModel.read(sObjectPath, {
				filters: sFilter,
				success: function (odata) {
					if (odata.results && odata.results[0]) {
						__controller.__addAttrInBuybackModel(odata.results[0]);
					}
				},
				error: function (oError) {
					if (oError.responseText && JSON.parse(oError.responseText).error.message) {
						MessageBox.show(
							JSON.parse(oError.responseText).error.message.value, {
								icon: sap.m.MessageBox.Icon.ERROR,
								title: "Error",
								actions: [sap.m.MessageBox.Action.OK]
							});
					} else {
						return;
					}
				}
			});
		},

		__addAttrInBuybackModel: function (oData) {
			var buybackDetailsModel = this.getModel("buybackDetailsModel");
			var buybackData = buybackDetailsModel.getData();
			for (var key in oData) {
				buybackData[key] = oData[key];
			}
			buybackData.EBELN = __controller.sEbeln;
			buybackDetailsModel.setProperty("/RGA_NUM1", buybackData.RGA_NUM);
			buybackDetailsModel.checkUpdate(true);
		},

		DateFormat: DateFormat.getDateInstance({
			pattern: "MM/dd/yyyy"
		}),
		onRTVDetail: function (oEvent) {
			if (sap.ushell && sap.ushell.Container && sap.ushell.Container.getService) {
				jQuery.sap.require("jquery.sap.storage");
				var oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
				oStorage.put("rtvNavBack", window.location.href);
				oStorage.put("buybackStorageTab", "complete");
				var that = this;
				var storid = this.StorId;
				var labelNum = oEvent.getSource().getProperty('text');
				var action = "display&/object/" + storid + "/" + labelNum + "";

				var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
				oCrossAppNavigator.toExternal({
					target: {
						semanticObject: "YSO_VIEWRTV",
						action: action
					}
				});

				// var dialog = new sap.m.Dialog({
				// 	title: that.getResourceBundle().getText("Warning"),
				// 	type: 'Message',
				// 	state: 'Warning',
				// 	content: new sap.m.Text({
				// 		text: that.getResourceBundle().getText("toRTV")
				// 	}),
				// 	beginButton: new sap.m.Button({
				// 		text: that.getResourceBundle().getText("Yes"),
				// 		press: function () {
				// 			dialog.close();

				// 			var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
				// 			oCrossAppNavigator.toExternal({
				// 				target: {
				// 					semanticObject: "YSO_VIEWRTV",
				// 					action: action
				// 				}
				// 			});
				// 		}
				// 	}),
				// 	endButton: new sap.m.Button({
				// 		text: that.getResourceBundle().getText("Cancel"),
				// 		press: function () {
				// 			dialog.close();
				// 		}
				// 	}),
				// 	afterClose: function () {
				// 		dialog.destroy();
				// 	}
				// });
				// dialog.open();
			} else {
				//alert("App to app navigation is not supported in this mode");
			}
		},

		formatDate: function (value) {
			if (!value) {
				return "";
			} else {
				var oLength = value.length;
				var oDate;
				if (oLength === 10) {
					oDate = value.slice(5, 7) + "/" + value.slice(8, 10) + "/" + value.slice(0, 4);
				} else {
					oDate = value.slice(4, 6) + "/" + value.slice(6, 8) + "/" + value.slice(0, 4);
				}
				return oDate;
				// return this.DateFormat.format(new Date(value.getTime() + new Date().getTimezoneOffset() * 60000));
				// return value;
			}
		},

		dueDateStatus: function (dueDate) {
			var currentDate = new Date();
			var futureDate = currentDate.setTime(currentDate.getTime() + (7 * 24 * 60 * 60 * 1000));
			var dueDateTime = Date.parse(dueDate);
			if (dueDateTime >= futureDate) {
				return "None";
			} else {
				return "Error";
			}
		},

		_onBindingChange: function () {
			var oView = this.getView(),
				oElementBinding = oView.getElementBinding();

			// No data for the binding
			if (!oElementBinding.getBoundContext()) {
				this.getRouter().getTargets().display("detailObjectNotFound");
				// if object could not be found, the selection in the master list
				// does not make sense anymore.
				this.getOwnerComponent().oListSelector.clearMasterListSelection();
				return;
			}

			var sPath = oElementBinding.getPath(),
				oResourceBundle = this.getResourceBundle(),
				oObject = oView.getModel().getObject(sPath),
				sObjectId = oObject.EBELN,
				sObjectName = oObject.NAME1,
				oViewModel = this.getModel("detailView");

			this.getOwnerComponent().oListSelector.selectAListItem(sPath);

			oViewModel.setProperty("/saveAsTileTitle", oResourceBundle.getText("shareSaveTileAppTitle", [sObjectName]));
			oViewModel.setProperty("/shareOnJamTitle", sObjectName);
			oViewModel.setProperty("/shareSendEmailSubject",
				oResourceBundle.getText("shareSendEmailObjectSubject", [sObjectId]));
			oViewModel.setProperty("/shareSendEmailMessage",
				oResourceBundle.getText("shareSendEmailObjectMessage", [sObjectName, sObjectId, location.href]));
		},

		_onMetadataLoaded: function () {
			// Store original busy indicator delay for the detail view
			var iOriginalViewBusyDelay = this.getView().getBusyIndicatorDelay(),
				oViewModel = this.getModel("detailView");

			// Make sure busy indicator is displayed immediately when
			// detail view is displayed for the first time
			oViewModel.setProperty("/delay", 0);

			// Binding the view will set it to not busy - so the view is always busy if it is not bound
			// oViewModel.setProperty("/busy", true);
			// Restore original busy indicator delay for the detail view
			oViewModel.setProperty("/delay", iOriginalViewBusyDelay);
		},

		_showButton: function (show) {
			if (show === false) {
				// var printBtn = this.byId("idPrintBtn");
				var saveBtn = this.byId("idSaveBtn");
				var submitBtn = this.byId("idSubmitBtn");
				// printBtn.setVisible(show);
				saveBtn.setVisible(show);
				submitBtn.setVisible(show);
			} else {
				this._AuthorizationVerifyAccess();
			}
		},

		onSubmit: function () {
			var scannedArticles = this.getView().getModel('buybackDetailsModel').getProperty("/ScannedArticles");
			var RGA_NUM_HDR = this.getView().getModel('buybackDetailsModel').getProperty("/RGA_NUM");
			var DISPOSITION_CODE = this.getView().getModel('buybackDetailsModel').getProperty("/DISPOSITION_CODE");

			var oSubmitBTn = this.getView().byId("idSubmitBtn");
			oSubmitBTn.setEnabled(false);

			if (scannedArticles != undefined && scannedArticles.length > 0) {
				var ItemBBSubmitSet = [];
				var oRequestPayload = {
					"EBELN": scannedArticles[0].EBELN,
					"WERKS": scannedArticles[0].WERKS
				};

				scannedArticles.forEach(function (r) {
					ItemBBSubmitSet.push({
						"EBELN": r.EBELN,
						"EBELP": r.EBELP,
						"REASON_CODE": r.REASON_CODE,
						"DISPOSITION_CODE": DISPOSITION_CODE,
						"RGA_NUM": RGA_NUM_HDR,
						"MATNR": r.MATNR,
						"MENGE": r.SAVED_QTY.toString(),
						"MEINS": r.MEINS,
						"WERKS": r.WERKS
					});
				});

				oRequestPayload.ItemBBSubmitSet = ItemBBSubmitSet;
				oRequestPayload.MsgBBSubmitSet = [];

				var that = this;
				this.getModel().create("/HeaderBBSubmitSet", oRequestPayload, {
					success: function (oData, oResponse) {
						var cart_messages = [];
						// var oSubmitBTn = that.getView().byId("idSubmitBtn");
						oSubmitBTn.setEnabled(true);
						that.getOwnerComponent().selectedItem.getBindingContext("buybackMasterModel").getObject().OPEN_COUNT = oData.OPEN_COUNT;
						if (oData.MsgBBSubmitSet.results != undefined && oData.MsgBBSubmitSet.results.length > 0) {
							that.getModel('buybackDetailsModel').setProperty('/messagePopoverBtnVisible', true);
							that.byId("messagePopoverBtn").setVisible(true);
							// sap.ui.core.BusyIndicator.hide();
							oData.MsgBBSubmitSet.results.forEach(function (r) {
								cart_messages.push({
									"type": r.TYPE,
									"title": r.MESSAGE,
									"subtitle": r.ARTICLE
								});
							});

							// }
							that.getModel('buybackDetailsModel').setProperty("/cart_messages", cart_messages);
							// if(oResponse.headers["sap-message"] != undefined
							// 	&& JSON.parse(oResponse.headers["sap-message"]).severity != undefined 
							// 	&& JSON.parse(oResponse.headers["sap-message"]).severity == "error"){
							// 		sap.m.MessageToast.show(JSON.parse(oResponse.headers["sap-message"]).message);
						} else {
							that.getModel('buybackDetailsModel').setProperty('/messagePopoverBtnVisible', false);
							that.byId("messagePopoverBtn").setVisible(false);

							var openCount =
								that.getView().getModel("buybackDetailsModel").getProperty("/OPEN_COUNT") -
								oData.ItemBBSubmitSet.results.length;

							that.getView().getModel("buybackDetailsModel").setProperty("/OPEN_COUNT", openCount);
							that.getOwnerComponent().selectedItem.getBindingContext("buybackMasterModel").getObject().OPEN_COUNT = openCount;
							sap.m.MessageToast.show(that.getResourceBundle().getText("submitSuccess"));
						}
						that.onRefreshDetail(oData.EBELN);
					},
					error: function (err, message) {
						oSubmitBTn.setEnabled(true);
						// sap.ui.core.BusyIndicator.hide();
						MessageBox.error(JSON.parse(err.responseText).error.message.value);
					}
				});

				sap.ui.getCore().getEventBus().publish("rtv.buyback", "RefreshMasterList");
			} else {

				sap.m.MessageToast.show(this.getResourceBundle().getText("scanBeforeSubmit"));
			}
		},

		initMessagePopover: function (oEvent) {

			var oMessageTemplate = new sap.m.MessageItem({
				type: '{buybackDetailsModel>type}',
				title: '{buybackDetailsModel>title}',
				activeTitle: "{buybackDetailsModel>active}",
				description: '{buybackDetailsModel>description}',
				subtitle: '{buybackDetailsModel>subtitle}',
				counter: '{buybackDetailsModel>counter}'
			});

			oMessagePopover = new sap.m.MessagePopover({
				items: {
					path: 'buybackDetailsModel>/cart_messages',
					template: oMessageTemplate
				},
				activeTitlePress: function () {
					sap.m.MessageToast.show(that.getResourceBundle().getText("activeTitle"));
				}
			});

			this.byId("messagePopoverBtn").addDependent(oMessagePopover);
		},

		// Display the button type according to the message with the highest severity
		// The priority of the message types are as follows: Error > Warning > Success > Info
		buttonTypeFormatter: function () {
			var sHighestSeverity;
			var aMessages = this.getView().getModel('buybackDetailsModel').getProperty('/cart_messages');
			// this.getView().getModel().getData();

			aMessages.forEach(function (sMessage) {
				switch (sMessage.type) {
				case "Error":
					sHighestSeverity = "Negative";
					break;
				case "Warning":
					sHighestSeverity = sHighestSeverity !== "Negative" ? "Critical" : sHighestSeverity;
					break;
				case "Success":
					sHighestSeverity = sHighestSeverity !== "Negative" && sHighestSeverity !== "Critical" ? "Success" : sHighestSeverity;
					break;
				default:
					sHighestSeverity = !sHighestSeverity ? "Neutral" : sHighestSeverity;
					break;
				}
			});

			return sHighestSeverity;
		},

		// Set the button icon according to the message with the highest severity
		buttonIconFormatter: function () {
			var sIcon;
			var aMessages = this.getView().getModel('buybackDetailsModel').getProperty('/cart_messages');
			// this.getView().getModel().getData();

			aMessages.forEach(function (sMessage) {
				switch (sMessage.type) {
				case "Error":
					sIcon = "sap-icon://message-error";
					break;
				case "Warning":
					sIcon = sIcon !== "sap-icon://message-error" ? "sap-icon://message-warning" : sIcon;
					break;
				case "Success":
					sIcon = "sap-icon://message-error" && sIcon !== "sap-icon://message-warning" ? "sap-icon://message-success" : sIcon;
					break;
				default:
					sIcon = !sIcon ? "sap-icon://message-information" : sIcon;
					break;
				}
			});

			return sIcon;
		},
		handleMessagePopoverPress: function (oEvent) {
			oMessagePopover.toggle(oEvent.getSource());
		},

		// ****************************************

		onTabChange: function (oEvent) {
			var oScanField,
				oSId;
			this._selectedTab = oEvent.getSource().getSelectedKey();
			// Store the tab selecteion
			jQuery.sap.require("jquery.sap.storage");
				var oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
				oStorage.put("rtvNavBack", window.location.href);
				oStorage.put("buybackStorageTab", this._selectedTab);
				
			if (oEvent.getSource().getSelectedKey() === "articles") {

				var oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
				oStorage.put("buybackStorageTab", "articles");

				oScanField = this.getView().byId("oScanArticle");
				oSId = oScanField.getId();
				this.onScanField(oSId);

				if (this.getModel('buybackDetailsModel').getProperty('/messagePopoverBtnVisible'))
					this.byId('messagePopoverBtn').setVisible(false);
				this.getModel('buybackDetailsModel').setProperty("/cart_messages", []);
				this._showButton(true);
			} else {
				this.byId('messagePopoverBtn').setVisible(false);
				this._showButton(false);
				// this.onScanField("");
			}
			if (oEvent.getSource().getSelectedKey() === "complete") {
				// this.onScanField("");
				var oFilters = [new Filter("EBELN", "EQ", this.getModel('buybackDetailsModel').getProperty('/EBELN')),
					new Filter("WERKS", "EQ", this.getModel('buybackDetailsModel').getProperty('/WERKS'))
				];
				var that = this;
				that.getModel('buybackDetailsModel').setProperty("/busy", true);
				that.getModel('buybackDetailsModel').setProperty("/CompleteArticles", []);
				this.getModel().read("/BBCompleteSet", {
					filters: oFilters,
					success: function (odata) {
						if (odata.results && odata.results[0]) {
							var aCompleteArticles = [];
							odata.results.forEach(function (item) {
								item.MATNR = __controller.formatter.removeLeadingZeroes(item.MATNR);
								aCompleteArticles.push(item);
							});
							that.getModel('buybackDetailsModel').setProperty("/CompleteArticles", aCompleteArticles);
						}
						that.getModel('buybackDetailsModel').setProperty("/busy", false);
					},
					error: function (oError) {}
				});
			} else {
				// this.onScanField("");
			}
		},

		onLabelScan: function (oEvent) {
			var sValue = oEvent.getSource().getValue();
			if (sValue.length >= 10) {
				this.onSearchArticle(oEvent);
			}
		},
		onSearchArticle: function (oEvent) {
			var sQuery = oEvent.getSource().getValue();
			oEvent.getSource().setValue("");
			var buybackDetailsModel = this.getModel("buybackDetailsModel");
			var buybackDetailsData = buybackDetailsModel.getData();
			var oI18N = this.getModel("i18nBuyback").getResourceBundle(),
				oMessage = oI18N.getText("NOT_PENDING");
			var oMsg = this.getResourceBundle().getText("Scanned");
			this._upcMatchIndex = "";
			if (sQuery === "") {
				return;
			}
			if (buybackDetailsData.ScannedArticles.some(function (item, i) {
					return (item.MATNR === sQuery);
				})) {
				this._upcMatchIndex = "";
				// console.log("Already scanned");
				return;
			} else if (!buybackDetailsData.PendingArticles.some(function (item, i) {
					return item.MATNR === sQuery;
				})) {
				var exit = false;
				for (var i = 0; i < buybackDetailsData.PendingArticles.length; i++) {
					var len = buybackDetailsData.PendingArticles[i].PO_DETAIL_ARTICLE_UPCSET.results.length;
					for (var j = 0; j < len; j++) {
						var poupc = buybackDetailsData.PendingArticles[i].PO_DETAIL_ARTICLE_UPCSET.results[j].EAN11;
						if (poupc === sQuery) {
							this._upcMatchIndex = i;
							exit = true;
							// return;
						}
					}
				}
				if (exit === false) {
					this._upcMatchIndex = "";
					console.log("Not in pending list");
					MessageToast.show((oMessage), {
						duration: 5000
					});
				}
				// return;
			}

			if (!buybackDetailsData.PendingArticles.some(function (item, i) {
					if (item && item.MATNR === sQuery) {
						buybackDetailsData.ScannedArticles = buybackDetailsData.ScannedArticles.concat(buybackDetailsData.PendingArticles.splice(i, 1));
						MessageToast.show(oMsg);
					}
				})) {
				if (this._upcMatchIndex !== "") {
					buybackDetailsData.ScannedArticles = buybackDetailsData.ScannedArticles.concat(buybackDetailsData.PendingArticles.splice(this._upcMatchIndex,
						1));
					MessageToast.show(oMsg);
				}
			}
			buybackDetailsModel.checkUpdate(true);
		},

		onRemoveScannedArticle: function (oEvent) {
			var buybackDetailsModel = this.getModel("buybackDetailsModel");
			var buybackDetailsData = buybackDetailsModel.getData();
			var index = oEvent.getParameter("listItem").getBindingContext("buybackDetailsModel").getPath().split("/")[2];
			buybackDetailsData.PendingArticles = buybackDetailsData.PendingArticles.concat(buybackDetailsData.ScannedArticles.splice(index, 1));
			buybackDetailsModel.checkUpdate(true);
		},

		onNavBack: function () {
			// sap.ui.getCore().getEventBus().publish("rtv.buyback", "ClearMasterLisSelection");
			this.getView().getAggregation('content')[0].setEnableScrolling(false);
			this.getRouter().navTo("masterBuyback", {}, true);
		},

		/*---------Email Merchant-------*/
		onMerchantEmailPress: function () {
			var buybackModel = this.getModel("buybackDetailsModel");
			var buybackModelData = buybackModel.getData();
			if (!this._emailPopUp) {
				this._emailPopUp = sap.ui.xmlfragment("merchatEmail", "YRTV_ONE_TILE.YRTV_ONE_TILE.view.Buyback.EmailMerchant", this);
				this.getView().addDependent(this._emailPopUp);
			}
			var emailCopyFld = sap.ui.getCore().byId("merchatEmail--EmailCopy");
			var emailToFld = sap.ui.getCore().byId("merchatEmail--EmailTo");
			buybackModelData.EMAIL_TO = buybackModelData.EMAIL_ADDRESS_HD;
			emailCopyFld.setValueState("None");
			emailToFld.setValueState("None");
			buybackModel.setProperty("/ValidCopyEmailAdd", true);
			buybackModel.checkUpdate(true);
			this._emailPopUp.open();
			jQuery.sap.delayedCall(10, __controller, function () {
				// that._emailPopUp.setBusy(true);
			});
		},
		onEmailCancelPress: function () {
			this._emailPopUp.close();
			var buybackModel = this.getModel("buybackDetailsModel");
			buybackModel.setProperty("/EMAIL_TO", "");
			buybackModel.setProperty("/EMAIL_CC", "");
			buybackModel.setProperty("/EMAIL_TEXT", "");
			buybackModel.checkUpdate(true);
		},

		onEmailSendPress: function () {
			var that = this;
			jQuery.sap.delayedCall(10, that, function () {
				that._emailPopUp.setBusy(true);
			});
			var oModel = this.getModel();
			var buybackModel = this.getModel("buybackDetailsModel");
			var buybackModelData = buybackModel.getData();
			var oUrlParameters = {
				"WERKS": "'" + buybackModelData.WERKS + "'",
				"EMAIL_TO": "'" + buybackModelData.EMAIL_TO + "'",
				"EMAIL_FROM": "'" + buybackModelData.EMAIL_FROM + "'",
				"EMAIL_CC": "'" + buybackModelData.EMAIL_CC + "'",
				"EMAIL_SUBJECT": "'" + buybackModelData.EMAIL_SUBJECT + "'",
				"EMAIL_TEXT": "'" + buybackModelData.EMAIL_TEXT + "'"
			};
			var sPath = "/EMAIL";

			oModel.read(sPath, {
				urlParameters: oUrlParameters,
				success: function (oData) {
					that._emailPopUp.close();
					that._emailPopUp.setBusy(false);
					buybackModel.setProperty("/EMAIL_TO", "");
					buybackModel.setProperty("/EMAIL_CC", "");
					buybackModel.setProperty("/EMAIL_TEXT", "");
					buybackModel.checkUpdate(true);
				},
				error: function (oError) {
					that._emailPopUp.setBusy(false);
					sap.m.MessageBox.show(
						JSON.parse(oError.responseText).error.message.value, {
							icon: sap.m.MessageBox.Icon.ERROR,
							title: "Error",
							actions: [sap.m.MessageBox.Action.OK],
							onClose: function (oAction) {}
						});
				}
			});
		},

		onEmailToChange: function (evt) {
			var emailToFld = evt.getSource();
			var enteredEmailTo = emailToFld.getValue();
			var emailCopyFld = sap.ui.getCore().byId("merchatEmail--EmailCopy");
			var emailRegex = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
			var buybackDetailsModel = this.getView().getModel("buybackDetailsModel");
			var EmailText = buybackDetailsModel.getProperty("/EMAIL_TEXT");
			if (enteredEmailTo.length !== 0) {
				if (EmailText.length !== 0) {
					if (emailRegex.test(enteredEmailTo)) {
						emailToFld.setValueState("None");
						buybackDetailsModel.setProperty("/ValidToEmailAdd", true);
						if (emailCopyFld.getValueState() !== "Error") {
							buybackDetailsModel.setProperty("/EnableEmailSend", true);
							buybackDetailsModel.setProperty("/ValidCopyEmailAdd", true);
						} else {
							buybackDetailsModel.setProperty("/EnableEmailSend", false);
							buybackDetailsModel.setProperty("/ValidCopyEmailAdd", false);
						}
					} else {
						emailToFld.setValueState("Error");
						buybackDetailsModel.setProperty("/ValidToEmailAdd", false);
						buybackDetailsModel.setProperty("/EnableEmailSend", false);
					}
				} else {
					if (emailRegex.test(enteredEmailTo)) {
						emailToFld.setValueState("None");
						buybackDetailsModel.setProperty("/ValidToEmailAdd", true);
					} else {
						emailToFld.setValueState("Error");
						buybackDetailsModel.setProperty("/ValidToEmailAdd", false);
					}
					buybackDetailsModel.setProperty("/EnableEmailSend", false);
				}
			} else {
				emailToFld.setValueState("Error");
				buybackDetailsModel.setProperty("/EnableEmailSend", false);
			}
			buybackDetailsModel.checkUpdate(true);
		},

		onEmailCopyChange: function (evt) {
			var emailCopyFld = evt.getSource();
			var emailToFld = sap.ui.getCore().byId("merchatEmail--EmailTo");
			var enteredEmailCopy = emailCopyFld.getValue();
			var emailRegex = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
			var emailArray = enteredEmailCopy.split(";");
			var buybackDetailsModel = this.getView().getModel("buybackDetailsModel");
			var EmailText = buybackDetailsModel.getProperty("/EMAIL_TEXT");
			var ValidToEmailAdd = buybackDetailsModel.getProperty("/ValidToEmailAdd");
			var validState = !emailArray.some(function (element, idx, array) {
				if (element.trim().length > 0) {
					if (emailRegex.test(element.trim())) {
						//buybackDetailsModel.setProperty("/ValidCopyEmailAdd", false);
						return false;
					} else {
						//buybackDetailsModel.setProperty("/ValidCopyEmailAdd", true);
						return true;
					}
				}
			});
			buybackDetailsModel.setProperty("/ValidCopyEmailAdd", validState);
			emailCopyFld.setValueState(validState ? "None" : "Error");
			buybackDetailsModel.setProperty("/EnableEmailSend", validState && emailToFld.getValue().length !== 0 && ValidToEmailAdd &&
				EmailText.length > 0, emailCopyFld.getBindingContext("buybackDetailsModel"));

		},

		onEmailTextChange: function (evt) {
			var emailText = evt.getSource().getValue();
			var buybackDetailsModel = this.getModel("buybackDetailsModel");
			var ValidToEmailAdd = buybackDetailsModel.getProperty("/ValidToEmailAdd");
			var ValidCopyEmailAdd = buybackDetailsModel.getProperty("/ValidCopyEmailAdd");
			var emailTo = buybackDetailsModel.getProperty("/EMAIL_TO");

			if (emailTo.trim().length !== 0 && ValidToEmailAdd && ValidCopyEmailAdd && emailText.trim().length !== 0) {
				buybackDetailsModel.setProperty("/EnableEmailSend", true);
			} else {
				buybackDetailsModel.setProperty("/EnableEmailSend", false);
			}
		},

		navigateToALU: function (oEvent) {
			if (sap.ushell && sap.ushell.Container && sap.ushell.Container.getService) {
				// jQuery.sap.require("jquery.sap.storage");
				// var oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.local);
				// oStorage.put("navBackFromALU", {
				// "navBackFromALU": true
				// });
				// jQuery.sap.require("jquery.sap.storage");
				// var oStorage = jQuery.sap.storage(jQuery.sap.storage.Type.session);
				// oStorage.put("rtvNavBack", window.location.href);
				// oStorage.put("buybackStorageTab", this._selectedTab);

				var article = oEvent.getSource().getText();
				var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
				// var storid = __controller.StoreId;
				var storid = this.StorId;

				var action = "Y_LOOKUP&/product/" + storid + "/00000000" + article + "";
				// var action = "Y_LOOKUP&/product/" + storid + "/" + article + "";
				oCrossAppNavigator.toExternal({
					target: {
						semanticObject: "Article",
						action: action
					}
				});

			} else {
				alert("App to app navigation is not supported in this mode");
			}
		},

		onSavePress: function () {
			var oViewModel = this.getModel("detailView");
			oViewModel.setProperty("/busy", true);
			var oModel = this.getModel();
			var buybackModel = this.getModel("buybackDetailsModel");
			var buybackModelData = buybackModel.getData();
			var scannedArticles = buybackModelData.ScannedArticles;
			var sPath = "/BUYBACK_HEADERSet";
			var buybackSaveSet = [];
			var payload = {
				"EBELN": buybackModelData.EBELN,
				"WERKS": __controller.StorId
			};
			scannedArticles.some(function (element, array, idx) {
				if (element.SAVED_QTY > 0) {
					var obj = {};
					obj.EBELN = buybackModelData.EBELN;
					obj.EBELP = element.EBELP;
					obj.MATNR = element.MATNR;
					obj.MENGE = element.SAVED_QTY.toString();
					obj.MEINS = element.MEINS;
					obj.WERKS = element.WERKS;
					buybackSaveSet.push(obj);
				}
			});

			payload.BUYBACK_SAVESet = buybackSaveSet;
			console.log(payload);

			oModel.create(sPath, payload, {
				success: function (oData) {
					oViewModel.setProperty("/busy", false);
					MessageBox.show(
						__controller.getResourceBundle().getText("saveQtySuccesMessage"), {
							icon: sap.m.MessageBox.Icon.SUCCESS,
							title: __controller.getResourceBundle().getText("success"),
							actions: [sap.m.MessageBox.Action.OK]
						});
				},
				error: function (oError) {
					if (oError.responseText && JSON.parse(oError.responseText).error.message) {
						MessageBox.show(
							JSON.parse(oError.responseText).error.message.value, {
								icon: sap.m.MessageBox.Icon.ERROR,
								title: __controller.getResourceBundle().getText("error"),
								actions: [sap.m.MessageBox.Action.OK]
							});
					} else {
						return;
					}
					oViewModel.setProperty("/busy", false);
				}
			});
		},

		onSaveQtyChange: function (evt) {
			var modelData = __controller.getModel("buybackDetailsModel").getData();
			var fld = evt.getSource();
			var value = evt.getParameter("value");
			var enteredQty = value.replace(/[^\d.]/g, "");
			if (Number(enteredQty) === 0 || Number(enteredQty) < 0 || enteredQty.length === 0) {
				modelData.enableSaveBtn = false;
				fld.setValueState("Error");
			} else {
				fld.setValueState("None");
			}
			fld.updateDomValue(enteredQty);
		},
		onOVBayInfoPress: function (oEvent) {
			var sPath = oEvent.getSource().getBindingContext("buybackDetailsModel").getPath(),
				oPath = sPath.slice(16, 18),
				vPath = oPath.slice(1, 2),
				oArtTyp = sPath.slice(1, 8);

			var buybackDetailsModel = this.getModel("buybackDetailsModel"),
				oArticles = buybackDetailsModel.getData(),
				oArticleList;

			if (oArtTyp === "Scanned") {
				oArticleList = oArticles.ScannedArticles;
			} else {
				oArticleList = oArticles.PendingArticles;
			}

			var ArticleTableInfoModel = this.getOwnerComponent().getModel("ArticleTableInfoModel");
			for (var i = 0; i < oArticleList.length; i++) {
				if (i === Number(vPath)) {
					ArticleTableInfoModel.setProperty("/OVBay", oArticleList[i].ToOHMBay.results);
				}
			}

			ArticleTableInfoModel.setProperty("/BayAdditionalDetailsField", "OVBay");
			ArticleTableInfoModel.updateBindings(true);
			ArticleTableInfoModel.refresh();

			this._getPopover().setModel(ArticleTableInfoModel);
			this._getPopover().openBy(oEvent.getSource());

		},
		onBayInfoPress: function (oEvent) {
			var sPath = oEvent.getSource().getBindingContext("buybackDetailsModel").getPath(),
				oPath = sPath.slice(16, 18),
				vPath = oPath.slice(1, 2),
				oArtTyp = sPath.slice(1, 8);

			var buybackDetailsModel = this.getModel("buybackDetailsModel"),
				oArticles = buybackDetailsModel.getData(),
				oArticleList;
			if (oArtTyp === "Scanned") {
				oArticleList = oArticles.ScannedArticles;
			} else {
				oArticleList = oArticles.PendingArticles;
			}

			var ArticleTableInfoModel = this.getOwnerComponent().getModel("ArticleTableInfoModel");
			for (var i = 0; i < oArticleList.length; i++) {
				if (i === Number(vPath)) {
					ArticleTableInfoModel.setProperty("/Bay", oArticleList[i].ToBay.results);
				}
			}

			ArticleTableInfoModel.setProperty("/BayAdditionalDetailsField", "Bay");
			ArticleTableInfoModel.updateBindings(true);
			ArticleTableInfoModel.refresh();

			this._getPopover().setModel(ArticleTableInfoModel);
			this._getPopover().openBy(oEvent.getSource());

		},
		_getPopover: function () {
			if (!this._oPopover) {
				this._oPopover = sap.ui.xmlfragment("bays", "YRTV_ONE_TILE.YRTV_ONE_TILE.view.Buyback.BayAdditionalDetails", this);
				this.getView().addDependent(this._oPopover);
			}
			return this._oPopover;
		},
		onBayInfoClose: function () {
			this._getPopover().close();
		},
		_AuthorizationVerifyAccess: function () {
			var oAuthModel = this.getOwnerComponent().getModel("oAuthModel"),
				oData = oAuthModel.getData(),
				oSaveBtn = this.byId("idSaveBtn"),
				oSubmitBtn = this.byId("idSubmitBtn");
			if (oData.results) {
				if (this._selectedTab !== "complete") {
					oSaveBtn.setVisible(
						oData.results.some(function (item) {
							return (item.Buyback === "Y");
						})
					);

					oSubmitBtn.setVisible(
						oData.results.some(function (item) {
							return (item.Buyback === "Y");
						})
					);
				}
			} else {
				this._AuthorizationAccess();
			}

		},
		_AuthorizationAccess: function () {
			var oModel = this.getModel();
			var oSaveBtn = this.byId("idSaveBtn"),
				oSubmitBtn = this.byId("idSubmitBtn");
			var oAuthModel = this.getOwnerComponent().getModel("oAuthModel");
			var that = this;
			sap.ui.core.BusyIndicator.show();
			oModel.read("/UserAuthSet", {
				success: function (oData, response) {
					oAuthModel.setData(oData);

					oSaveBtn.setVisible(
						oData.results.some(function (item) {
							return (item.Buyback === "Y");
						})
					);

					oSubmitBtn.setVisible(
						oData.results.some(function (item) {
							return (item.Buyback === "Y");
						})
					);

					sap.ui.core.BusyIndicator.hide();
				},
				error: function (oError) {
					that.createRTVBtn.setVisible(false);
					sap.ui.core.BusyIndicator.hide();
				}
			});
		}

	});

});