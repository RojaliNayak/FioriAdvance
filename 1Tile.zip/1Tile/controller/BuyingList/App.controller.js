sap.ui.define([
		"YRTV_ONE_TILE/YRTV_ONE_TILE/controller/Buyback/BaseController",
		"sap/ui/model/json/JSONModel"
	], function (BaseController, JSONModel) {
		"use strict";

		return BaseController.extend("YRTV_ONE_TILE.YRTV_ONE_TILE.controller.Buyback.App", {

			onInit : function () {
				var oListSelector = this.getOwnerComponent().oListSelector;

				// Makes sure that master view is hidden in split app
				// after a new list entry has been selected.
				oListSelector.attachListSelectionChange(function () {
					this.byId("idAppBuyback").hideMaster();
				}, this);

				// apply content density mode to root view
				this.getView().addStyleClass(this.getOwnerComponent().getContentDensityClass());
			}

		});

	}
);