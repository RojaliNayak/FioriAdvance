sap.ui.define([], function () {
	"use strict";

	return {

		/**
		 * Rounds the number unit value to 2 digits
		 * @public
		 * @param {string} sValue the number string to be rounded
		 * @returns {string} sValue with 2 digits rounded
		 */
		numberUnit: function (sValue) {
			if (!sValue) {
				return "";
			}
			return parseFloat(sValue).toFixed(2);
		},

		formatDate: function (value) {
			if (!value) {
				if (sap.ui.Device.system.phone){
					return this.getResourceBundle().getText("AuditDate") + "";
				}
				else{
					return "";
				}
			} else {
				// if($.isFunction(value.getTime)) {
				// return this.DateFormat.format(new Date(value.getTime() + new Date().getTimezoneOffset() * 60000));
				// } else {
				// 	return value;
				// }
				
				if (value === "00000000") {
					return "";
					
				} else if (value !== "00000000") {
					var oLength = value.length;
					var oDate;
					if (oLength === 10) {
						oDate = value.slice(5, 7) + "/" + value.slice(8, 10) + "/" + value.slice(0, 4);
					} else {
						oDate = value.slice(4, 6) + "/" + value.slice(6, 8) + "/" + value.slice(0, 4);
					}
					return oDate;
					
				} else {
					return value;
				}
			}
		},

		formatCost: function (cost) {
			var sCost;
			if (parseInt(cost) === parseFloat(cost)) {
				sCost = (parseInt(cost)).toString();
				return ("$" + sCost);
			} else {
				sCost = (parseFloat(cost).toFixed(2)).toString();
				return ("$" + sCost);
			}
		}

	};

});