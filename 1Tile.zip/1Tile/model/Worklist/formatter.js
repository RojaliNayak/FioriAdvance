sap.ui.define(["sap/ui/core/format/DateFormat"], function (DateFormat) {
	"use strict";

	return {
		/**
		 * Rounds the number unit value to 2 digits
		 * @public
		 * @param {string} sValue the number string to be rounded
		 * @returns {string} sValue with 2 digits rounded
		 */

		navigationForAwating: function (status) {
			// if (status === this.getResourceBundle().getText("AwaitingVendorMinimum")) {
			if (status === "320") {
				return;
			} else {
				return "Navigation";
			}
		},

		getAccNum: function (value) {
			if (value === "C") {
				return true;
			} else {
				return false;
			}
		},
		getCrContct: function (fTerm, oReason) {
			if ((fTerm === "C") && (oReason === "06" || "21")) {
				return true;
			} else {
				return false;
			}
		},

		labelIconColor: function (printLabel) {

			if (printLabel === "X") {
				return "red";
			} else {
				return "";
			}
		},

		dueDateFormatter: function (date, status) {
			if (status === this.getResourceBundle().getText("AwaitingVendorMinimum")) {
				return this.getResourceBundle().getText("PENDING");
			} else {
				return date;
			}
		},
		
		labelsFormatter: function (items) {
			return "Queen George the sexy";
		},

		vendorMinAwaiting: function (vendorMin) {
			var sTotalCost = vendorMin;
			var sCost;
			if (parseInt(sTotalCost) === 0) {
				return " ";
			} else if (parseInt(sTotalCost) === parseFloat(sTotalCost)) {
				sCost = (parseInt(sTotalCost)).toString();
				return ("$" + sCost);
			} else {
				sCost = (parseFloat(sTotalCost).toFixed(2)).toString();
				return ("$" + sCost);
			}
		},

		printLabelEnabled: function (printLabel) {
			if (printLabel === "X") {
				return false;
			} else {
				return true;
			}
		},

		formatePickupDate: function (value) {
			if (!value) {
				return this.getResourceBundle().getText("PENDING");
			} else {
				if ($.isFunction(value.getTime)) {
					return this.DateFormat.format(new Date(value.getTime() + new Date().getTimezoneOffset() * 60000));
				} else {
					if (value === "00000000") {
						return this.getResourceBundle().getText("PENDING");
					} else if (value !== "00000000") {
						var oLength = value.length;
						var oDate;
						if (oLength === 10) {
							oDate = value.slice(5, 7) + "/" + value.slice(8, 10) + "/" + value.slice(0, 4);
						} else {
							oDate = value.slice(4, 6) + "/" + value.slice(6, 8) + "/" + value.slice(0, 4);
						}
						return oDate;
					} else {
						return value;
					}
				}
			}

		},
		buttonText: function(type){
			
		},

		enableWeightFld: function (weight) {
			if (Number(weight) > 0) {
				return false;
			} else {
				return true;
			}
		},

		valueWeightFld: function (weight) {
			if (parseFloat(weight) > 0) {
				return parseFloat(weight);
			} else {
				return null;
			}
		},

		formatDate: function (value) {
			if (!value) {
				return "";
			} else {
				if (value === this.getResourceBundle().getText("PENDING")) {
					return this.getResourceBundle().getText("PENDING");
				} else {
					if (value !== "00000000") {
						var oLength = value.length;
						var oDate;
						if (oLength === 10) {
							oDate = value.slice(5, 7) + "/" + value.slice(8, 10) + "/" + value.slice(0, 4);
						} else {
							oDate = value.slice(4, 6) + "/" + value.slice(6, 8) + "/" + value.slice(0, 4);
						}
						return oDate;
					} else if (value === "00000000") {
						return "";
					}
				}

			}
		},

		dueDateAndIcon: function (value) {
			var oTDate = new Date();
			if (!value) {
				return false;
			} else {
				if (value === this.getResourceBundle().getText("PENDING")) {
					return this.getResourceBundle().getText("PENDING");
				} else {
					if (value !== "00000000") {
						var oLength = value.length;
						var oDate;
						if (oLength === 10) {
							oDate = value.slice(5, 7) + "/" + value.slice(8, 10) + "/" + value.slice(0, 4);
							var oNewDate1 = new Date(oDate);
							if (oNewDate1 < oTDate) {
								return true;
							} else {
								return false;
							}

						} else {
							oDate = value.slice(4, 6) + "/" + value.slice(6, 8) + "/" + value.slice(0, 4);
							var oNewDate2 = new Date(oDate);
							if (oNewDate2 < oTDate) {
								return true;
							} else {
								return false;
							}
						}
					} else if (value === "00000000") {
						return false;
					}
				}

			}

		

		},

		totalCost: function (MENGE, ITEM_COST) {
			var sTotalCost = ((MENGE * ITEM_COST).toFixed(2));
			var sCost;
			if (parseInt(sTotalCost) === parseFloat(sTotalCost)) {
				sCost = (parseInt(sTotalCost)).toString();
				return ("$" + sCost);
			} else {
				sCost = (parseFloat(sTotalCost).toFixed(2)).toString();
				return ("$" + sCost);
			}
		},

		itemCost: function (cost) {
			var sCost;
			if (parseInt(cost) === parseFloat(cost)) {
				sCost = (parseInt(cost)).toString();
				return ("$" + sCost);
			} else {
				sCost = (parseFloat(cost).toFixed(2)).toString();
				return ("$" + sCost);
			}
		},
		labelColor: function (label) {
			if (label.indexOf('98181') === 0) {
				return 'redLabelWorklist';
			}
		},

		qtyFormat: function (iQty) {
			var fQty = (Math.floor(parseFloat(iQty) * 100)) / 100;
			if (parseInt(iQty) === fQty) {
				return parseInt(iQty);
			} else {
				return fQty;
			}
		},

		formatNA: function (name, number) {
			if (name) {
				return (name + " " + number);
			} else {
				return "NA";
			}
		},
		vendorIdNameFormat: function (id, name) {
			var vendorNumber;
			if (id) {
				vendorNumber = Number(id) ? Number(id).toString() : id;
			}
			return name + " - " + vendorNumber;
		},
		
		// colorCode: function (labelNum){
		// 	var color;
		// 	if (labelNum.indexOf('98181') === 0){
		// 		color = "Red";
		// 	} else if (labelNum.indexOf('98182') === 0){
		// 		color = "Yellow";
		// 	}else if (labelNum.indexOf('98183') === 0) {
		// 		clolor = "Green";
		// 	}else if (labelNum.indexOf('98184') === 0) {
		// 		color = "White";
		// 	}
		// 	return color;
		// }

	};

});