sap.ui.define([
		"sap/ui/model/json/JSONModel",
		"sap/ui/Device"
	], function (JSONModel, Device) {
		"use strict";

		return {
			createDeviceModel : function () {
				var oModel = new JSONModel(Device);
				oModel.setDefaultBindingMode("OneWay");
				
				// The "reponder" URL parameter defines if the app shall run with mock data
			    var responderOn = jQuery.sap.getUriParameters().get("responderOn");
			    
			    // set the flag for later usage
			    model.Config.isMock = ("true" === responderOn);
				return oModel;
			}
		};
	}
);