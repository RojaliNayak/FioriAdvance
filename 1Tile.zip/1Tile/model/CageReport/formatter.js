sap.ui.define([], function () {
	"use strict";

	return {

		/**
		 * Rounds the number unit value to 2 digits
		 * @public
		 * @param {string} sValue the number string to be rounded
		 * @returns {string} sValue with 2 digits rounded
		 */
		numberUnit: function (sValue) {
			if (!sValue) {
				return "";
			}
			return parseFloat(sValue).toFixed(2);
		},

		truncateValue: function (value) {
			if (value !== undefined) {
				var sValue = (parseFloat(value).toFixed(2)).toString();

				if (parseInt(sValue.split(".")[1]) === 0) {
					return "$" + parseInt(sValue);
				} else {
					return "$" + (parseFloat(sValue)).toFixed(2);
				}
			}
		},

		truncateQty: function (value, unit) {

			var sValue = (parseFloat(value).toFixed(2)).toString();

			if (parseInt(sValue.split(".")[1]) === 0) {
				return parseInt(sValue) + unit;
			} else {
				return (parseFloat(sValue)).toFixed(2) + unit;
			}
		},

		labelNumberFormat: function (labelNum) {
			return labelNum ? "'" + labelNum + "'" : "";
		},
		getFormattedDate: function (date) {
			if (date) {
				if (date === "00000000") {
					return "";
				} else if (date !== "00000000") {
					var oLength = date.length;
					var oDate;
					if (oLength === 10) {
						oDate = date.slice(5, 7) + "/" + date.slice(8, 10) + "/" + date.slice(0, 4);
					} else {
						oDate = date.slice(4, 6) + "/" + date.slice(6, 8) + "/" + date.slice(0, 4);
					}
					return oDate;
				} else {
					return date;
				}
			}
		}

	};

});