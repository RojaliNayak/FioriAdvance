sap.ui.define([
	] , function () {
		"use strict";

		return {

			/**
			 * Rounds the number unit value to 2 digits
			 * @public
			 * @param {string} sValue the number string to be rounded
			 * @returns {string} sValue with 2 digits rounded
			 */
			dateFormat : function (sValue) {
				if (!sValue || sValue == "0000-00-00") {
					return this.getResourceBundle().getText("NA");
				}
				return sValue.toString().substring(5, 7) + "/" + sValue.toString().substring(8,10) + "/" + sValue.toString().substring(0, 4);
			},
			
			dateFormat1 : function (sValue) {
				if (!sValue || sValue == "00000000") {
					return this.getResourceBundle().getText("NA");
				}
				return sValue.toString().substring(4, 6) + "/" + sValue.toString().substring(6,8) + "/" + sValue.toString().substring(0, 4);
			},

			matnrFormat : function (sValue) {
				if (!sValue || sValue == "000000000000000000") {
					return this.getResourceBundle().getText("NA");
				} else {
					return sValue.toString().substring(8, 18) ;
				}
			},
			
			formatDate: function(value) {
				if (!value) {
					return "";
				} else {
					var oLength = value.length;
					var	oDate;
					if(oLength === 10){
					oDate = value.slice(5, 7) + "/" + value.slice(8, 10) + "/" + value.slice(0, 4);
					} else {
					oDate = value.slice(4,6) + "/" + value.slice(6, 8) + "/" + value.slice(0, 4);
					}
					return oDate;
					// return this.DateFormat.format(new Date(value.getTime() + new Date().getTimezoneOffset() * 60000));

						
				}
			},
			
			vendorFormat : function (sLifnr, sName) {
				return sName;
			},
			
			itemCost: function(cost)  {
				var sCost;
				if(parseInt(cost) === parseFloat(cost))
				{
					sCost = (parseInt(cost)).toString();
					return ("$" + sCost);
				}
				else {
					sCost = (parseFloat(cost).toFixed(2)).toString();
					return ("$" + sCost);
				}
			},
			
			qtyFormat: function(iQty){
				var fQty = (Math.floor(parseFloat(iQty) * 100))/100;
				if(parseInt(iQty) === fQty)
				{
					return parseInt(iQty);
				}
				else {
					return fQty;
				}
			}
		};

	}
);