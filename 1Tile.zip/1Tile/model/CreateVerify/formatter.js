sap.ui.define([], function () {
	"use strict";

	return {
		/**
		 * Rounds the currency value to 2 digits
		 *
		 * @public
		 * @param {string} sValue value to be formatted
		 * @returns {string} formatted currency value with 2 digits
		 */
		itemCost: function (cost) {
			var sCost;
			if (parseInt(cost) === parseFloat(cost)) {
				sCost = (parseInt(cost)).toString();
				return ("$" + sCost);
			} else {
				sCost = (parseFloat(cost).toFixed(2)).toString();
				return ("$" + sCost);
			}
		},

		onlineOnly: function (onlineOnly) {
			if (onlineOnly) {
				return this.getResourceBundle().getText("Yes");
			} else {
				return this.getResourceBundle().getText("No");
			}
		},

		vendorText: function (code, text) {
			if (code) {
				return Number(code) + " - " + text;
			}
		},

		qtyFormat: function (iQty) {
			var fQty = (Math.floor(parseFloat(iQty) * 100)) / 100;
			if (parseInt(iQty) === fQty) {
				return parseInt(iQty);
			} else {
				return fQty;
			}
		},
		defAllowance: function (defAllowance) {
			if ( Number(defAllowance) > 0 ){
				return this.getResourceBundle().getText("Yes");
			} else {
				return this.getResourceBundle().getText("No");
			}
			// return Number(defAllowance) > 0 ? "Yes" : "No";
		},

	};

});