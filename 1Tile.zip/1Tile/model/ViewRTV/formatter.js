sap.ui.define([], function () {
	"use strict";

	return {
		/**
		 * Rounds the currency value to 2 digits
		 *
		 * @public
		 * @param {string} sValue value to be formatted
		 * @returns {string} formatted currency value with 2 digits
		 */

		articleNum: function (sValue) {
			if (!sValue) {
				return "";
			}
			return sValue.toString(); //.substring(8, 18);
		},

		formatDate: function (value) {
			if (!value) {
				return this.getResourceBundle().getText("NA");
			} else {
				var oLength = value.length;
				var oDate;
				if (oLength === 10) {
					oDate = value.slice(5, 7) + "/" + value.slice(8, 10) + "/" + value.slice(0, 4);
				} else {
					oDate = value.slice(4, 6) + "/" + value.slice(6, 8) + "/" + value.slice(0, 4);
				}
				return oDate;
				// return this.DateFormat.format(new Date(value.getTime() + new Date().getTimezoneOffset() * 60000));
			}
		},

		qtyFormat: function (iQty) {
			var fQty = (Math.floor(parseFloat(iQty) * 100)) / 100;
			if (parseInt(iQty) === fQty) {
				return parseInt(iQty);
			} else {
				return fQty;
			}
		},

		totalCost: function (MENGE, ITEM_COST) {
			var sTotalCost = ((MENGE * ITEM_COST).toFixed(2));
			var sCost;
			if (parseInt(sTotalCost) === parseFloat(sTotalCost)) {
				sCost = (parseInt(sTotalCost)).toString();
				return ("$" + sCost);
			} else {
				sCost = (parseFloat(sTotalCost).toFixed(2)).toString();
				return ("$" + sCost);
			}
		},
		
		order        : function (pscFlag, comVbeln, refVbeln) {
			var sValue = "";
			if (pscFlag === "X"){
				sValue = refVbeln;
			}
			else{
				sValue = comVbeln;
			}
			
			if (!sValue) {
				return this.getResourceBundle().getText("NA");
			}
			if (sValue == "" || parseInt(sValue) === 0) {
				return this.getResourceBundle().getText("NA");
			}
			return sValue.toString();
		},

		na: function (sValue) {
			if (!sValue) {
				return this.getResourceBundle().getText("NA");
			}
			if (sValue == "" || parseInt(sValue) === 0) {
				return this.getResourceBundle().getText("NA");
			}
			return sValue.toString();
		},

		historyUpdatedNavigation: function (date) {
			if (!date) {
				return "Inactive";
			} else {
				return "Navigation";
			}
		},

		updatedHistory: function (text, date) {
			if (!date) {
				return this.getResourceBundle().getText("NA");
			} else {
				var formattedDate = this.DateFormat.format(new Date(date.getTime() + new Date().getTimezoneOffset() * 60000));
				return text + " " + formattedDate;
			}
		},

		itemCost: function (cost) {
			var sCost;
			if (parseInt(cost) === parseFloat(cost)) {
				sCost = (parseInt(cost)).toString();
				return ("$" + sCost);
			} else {
				sCost = (parseFloat(cost).toFixed(2)).toString();
				return ("$" + sCost);
			}
		},

		trimLeadZero: function (sValue) {
			if (!sValue) {
				return this.getResourceBundle().getText("NA");
			}
			if (sValue == "") {
				return this.getResourceBundle().getText("NA");
			}

			return sValue.toString().replace(/^0+/, '');
		},

		metVendor: function (sValue) {

			if (sValue === "Y") {
				return this.getResourceBundle().getText("Yes");
			} else if (sValue === "N") {
				return this.getResourceBundle().getText("No");
			}
			return this.getResourceBundle().getText("NA");
		},

		timeConv: function (date, time) {
			if ((date !== "") && (time.ms !== 0)) {
				var oLength = date.length;
				var oDate;
				if (oLength !== "00000000") {
					if (oLength === 10) {
						oDate = date.slice(5, 7) + "/" + date.slice(8, 10) + "/" + date.slice(0, 4);
					} else {
						oDate = date.slice(4, 6) + "/" + date.slice(6, 8) + "/" + date.slice(0, 4);
					}
					var dateUTC = new Date(oDate).toISOString();
					dateUTC = dateUTC.split("T")[0];
					var timeUTC = new Date(time.ms).toISOString();
					timeUTC = timeUTC.split("T")[1];
					timeUTC = timeUTC.split(".")[0];

					var formattedDate = dateUTC.split("-")[1] + ("/") + dateUTC.split("-")[2] + ("/") + dateUTC.split("-")[0];

					var hours = parseInt(timeUTC.substring(0, 2));
					var min_sec = timeUTC.substring(2, 8);
					if (hours) {
						if (hours > 23 || hours < 0) {
							return formattedDate + " " + timeUTC;
						} else if (hours === 0) { // 12 a.m.
							return formattedDate + " " + "12" + min_sec + "am";
						} else if (hours < 12) { // a.m.
							return formattedDate + " " + hours + min_sec + "am";
						} else if (hours === 12) { // 12 p.m.
							return formattedDate + " " + "12" + min_sec + "pm";
						} else if (hours > 12) { // p.m.
							hours = hours - 12;
							if (hours > 9) {
								return formattedDate + " " + hours + min_sec + "pm";
							} else {
								return formattedDate + " 0" + hours + min_sec + "pm";
							}
						}
					} else {
						return formattedDate + " " + timeUTC;
					}
				}

			}
		},

		navigationForAwating: function (status) {
			if (status === "Awaiting Vendor Minimum") {
				return;
			} else {
				return "Navigation";
			}
		},

		labelIconColor: function (printLabel) {

			if (printLabel === "X") {
				return "red";
			} else {
				return "";
			}
		},

		dueDateFormatter: function (date, status) {
			if (status === "Awaiting Vendor Minimum") {
				return "Pending";
			} else {
				return date;
			}
		},

		printLabelSelect: function (printLabel) {
			if (printLabel === "X") {
				return true;
			} else {
				return false;
			}
		},

		printLabelEnabled: function (printLabel) {
			if (printLabel === "X") {
				return false;
			} else {
				return true;
			}
		},

		onlineOnly: function (sValue) {

			if (sValue == "40") {
				return this.getResourceBundle().getText("Yes");
			}
			return this.getResourceBundle().getText("No");
		},

		countNumber: function (s1, s2, s3, s4) {
			var counter = 0;
			if (s1 && s1 !== "") {
				counter++;
			}
			if (s2 && s2 !== "") {
				counter++;
			}
			if (s3 && s3 !== "") {
				counter++;
			}
			if (s4 && s4 !== "") {
				counter++;
			}
			return parseInt(counter);
		}

	};

});