sap.ui.define([
		"sap/ui/model/json/JSONModel",
		"sap/ui/Device"
	], function (JSONModel, Device) {
		"use strict";

		return {
			createDeviceModel : function () {
				var oModel = new JSONModel(Device);
				oModel.setDefaultBindingMode("OneWay");
				return oModel;
			},

			createFLPModel : function () {
				var fnGetuser = jQuery.sap.getObject("sap.ushell.Container.getUser"),
					bIsShareInJamActive = fnGetuser ? fnGetuser().isJamActive() : false,
					oModel = new JSONModel({
						isShareInJamActive: bIsShareInJamActive
					});
				oModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
				return oModel;
			},
			
			createScreenModel : function () {
			
				var phone = Device.system.phone,
				
					bIsMasterOpen = phone ? false : true,
					oModel = new JSONModel({
						isMasterClose: phone,
						size: Device.resize.width,
						detailPath : ""
					});
				oModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
				return oModel;
			},
			
			createCommentModel : function () {
				var oModel = new JSONModel({
					Comments: [],
					SecondDispositionSet: [],
					DeleteReasonSet:[],
					Count: 0
				});
				oModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
				return oModel;
			},
			
			createTrackingModel : function () {
				var oModel = new JSONModel({
					Numbers: [],
					Count: 0
				});
				oModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
				return oModel;
			}
			
		};

	}
);